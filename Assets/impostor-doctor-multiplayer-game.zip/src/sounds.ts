// Simple sound synthesizer using Web Audio API
const audioCtx = typeof window !== 'undefined' ? new (window.AudioContext || (window as any).webkitAudioContext)() : null;

function playTone(frequency: number, duration: number, type: OscillatorType = 'sine', volume: number = 0.15) {
  if (!audioCtx) return;
  try {
    const oscillator = audioCtx.createOscillator();
    const gainNode = audioCtx.createGain();
    oscillator.connect(gainNode);
    gainNode.connect(audioCtx.destination);
    oscillator.type = type;
    oscillator.frequency.value = frequency;
    gainNode.gain.setValueAtTime(volume, audioCtx.currentTime);
    gainNode.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + duration);
    oscillator.start(audioCtx.currentTime);
    oscillator.stop(audioCtx.currentTime + duration);
  } catch {
    // Audio not available
  }
}

export function playCountdown() {
  playTone(440, 0.15, 'sine', 0.1);
}

export function playNightFall() {
  playTone(200, 1, 'sine', 0.08);
  setTimeout(() => playTone(150, 1.5, 'sine', 0.06), 500);
}

export function playKillSound() {
  playTone(100, 0.3, 'sawtooth', 0.12);
  setTimeout(() => playTone(80, 0.5, 'sawtooth', 0.1), 100);
  setTimeout(() => playTone(60, 0.8, 'sawtooth', 0.08), 200);
}

export function playShieldSound() {
  playTone(600, 0.2, 'sine', 0.1);
  setTimeout(() => playTone(800, 0.2, 'sine', 0.1), 100);
  setTimeout(() => playTone(1000, 0.3, 'sine', 0.08), 200);
}

export function playSelectSound() {
  playTone(500, 0.08, 'sine', 0.06);
}

export function playConfirmSound() {
  playTone(400, 0.1, 'sine', 0.08);
  setTimeout(() => playTone(600, 0.15, 'sine', 0.08), 80);
}

export function playVictorySound() {
  [523, 659, 784, 1047].forEach((freq, i) => {
    setTimeout(() => playTone(freq, 0.3, 'sine', 0.1), i * 150);
  });
}

export function playDefeatSound() {
  [400, 350, 300, 200].forEach((freq, i) => {
    setTimeout(() => playTone(freq, 0.4, 'triangle', 0.1), i * 200);
  });
}

export function playRevealSound() {
  playTone(300, 0.2, 'triangle', 0.08);
  setTimeout(() => playTone(450, 0.3, 'triangle', 0.08), 150);
}

export function resumeAudioContext() {
  if (audioCtx && audioCtx.state === 'suspended') {
    audioCtx.resume();
  }
}
