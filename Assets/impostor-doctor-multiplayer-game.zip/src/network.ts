import Peer, { DataConnection } from 'peerjs';
import { GameRoom, Player, ChatMessage, Vote, BotDifficulty } from './types';

export type NetworkMessage =
  | { type: 'room-state'; room: GameRoom }
  | { type: 'player-joined'; player: Player }
  | { type: 'player-left'; playerId: string }
  | { type: 'game-start' }
  | { type: 'impostor-kill'; impostorId: string; targetId: string }
  | { type: 'impostor-done'; impostorId: string }
  | { type: 'doctor-shield'; doctorId: string; targets: string[] }
  | { type: 'doctor-done'; doctorId: string }
  | { type: 'chat'; message: ChatMessage }
  | { type: 'vote'; vote: Vote }
  | { type: 'next-round' }
  | { type: 'reset-game' }
  | { type: 'add-bot'; difficulty: BotDifficulty }
  | { type: 'remove-bot'; botId: string }
  | { type: 'ping' }
  | { type: 'pong' };

type MessageHandler = (msg: NetworkMessage, fromId: string) => void;

class NetworkManager {
  private peer: Peer | null = null;
  private connections: Map<string, DataConnection> = new Map();
  private hostConnection: DataConnection | null = null;
  private messageHandler: MessageHandler | null = null;
  private _isHost: boolean = false;
  private _peerId: string | null = null;
  private _roomCode: string | null = null;
  private onConnectedCallback: (() => void) | null = null;
  private onDisconnectedCallback: ((reason: string) => void) | null = null;
  private onErrorCallback: ((error: string) => void) | null = null;
  private reconnectAttempts: number = 0;
  private maxReconnectAttempts: number = 3;

  get isHost(): boolean {
    return this._isHost;
  }

  get peerId(): string | null {
    return this._peerId;
  }

  get roomCode(): string | null {
    return this._roomCode;
  }

  get isConnected(): boolean {
    if (this._isHost) {
      return this.peer !== null && !this.peer.destroyed;
    }
    return this.hostConnection !== null && this.hostConnection.open;
  }

  get connectedPeers(): number {
    return this.connections.size;
  }

  setMessageHandler(handler: MessageHandler) {
    this.messageHandler = handler;
  }

  onConnected(callback: () => void) {
    this.onConnectedCallback = callback;
  }

  onDisconnected(callback: (reason: string) => void) {
    this.onDisconnectedCallback = callback;
  }

  onError(callback: (error: string) => void) {
    this.onErrorCallback = callback;
  }

  // Generate a short room code from peer ID
  private generateRoomCode(): string {
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    let code = '';
    for (let i = 0; i < 6; i++) {
      code += chars[Math.floor(Math.random() * chars.length)];
    }
    return code;
  }

  // Create room as host
  async createRoom(): Promise<string> {
    return new Promise((resolve, reject) => {
      this.cleanup();
      this._isHost = true;
      this._roomCode = this.generateRoomCode();
      
      // Use room code as peer ID for easy joining
      const peerId = `shadow-${this._roomCode}`;
      
      this.peer = new Peer(peerId, {
        debug: 0,
      });

      const timeout = setTimeout(() => {
        reject(new Error('Connection timeout'));
        this.cleanup();
      }, 15000);

      this.peer.on('open', (id) => {
        clearTimeout(timeout);
        this._peerId = id;
        console.log('Host created with ID:', id);
        
        this.peer!.on('connection', (conn) => {
          this.handleIncomingConnection(conn);
        });

        resolve(this._roomCode!);
      });

      this.peer.on('error', (err) => {
        clearTimeout(timeout);
        console.error('Peer error:', err);
        if (err.type === 'unavailable-id') {
          // Room code already in use, generate new one
          this._roomCode = this.generateRoomCode();
          this.cleanup();
          this.createRoom().then(resolve).catch(reject);
        } else {
          this.onErrorCallback?.(`Connection error: ${err.type}`);
          reject(err);
        }
      });

      this.peer.on('disconnected', () => {
        console.log('Host disconnected from signaling server');
        if (this.reconnectAttempts < this.maxReconnectAttempts) {
          this.reconnectAttempts++;
          this.peer?.reconnect();
        }
      });
    });
  }

  // Join room as client
  async joinRoom(roomCode: string): Promise<void> {
    return new Promise((resolve, reject) => {
      this.cleanup();
      this._isHost = false;
      this._roomCode = roomCode.toUpperCase();
      
      const hostPeerId = `shadow-${this._roomCode}`;
      
      this.peer = new Peer({
        debug: 0,
      });

      const timeout = setTimeout(() => {
        reject(new Error('Connection timeout - room may not exist'));
        this.cleanup();
      }, 15000);

      this.peer.on('open', (id) => {
        this._peerId = id;
        console.log('Client created with ID:', id);
        
        // Connect to host
        const conn = this.peer!.connect(hostPeerId, {
          reliable: true,
        });

        conn.on('open', () => {
          clearTimeout(timeout);
          console.log('Connected to host');
          this.hostConnection = conn;
          this.setupConnectionHandlers(conn);
          this.onConnectedCallback?.();
          resolve();
        });

        conn.on('error', (err) => {
          clearTimeout(timeout);
          console.error('Connection error:', err);
          reject(new Error('Failed to connect to room'));
        });
      });

      this.peer.on('error', (err) => {
        clearTimeout(timeout);
        console.error('Peer error:', err);
        if (err.type === 'peer-unavailable') {
          reject(new Error('Room not found'));
        } else {
          reject(new Error(`Connection error: ${err.type}`));
        }
      });
    });
  }

  private handleIncomingConnection(conn: DataConnection) {
    console.log('Incoming connection from:', conn.peer);
    
    conn.on('open', () => {
      console.log('Connection opened with:', conn.peer);
      this.connections.set(conn.peer, conn);
      this.setupConnectionHandlers(conn);
      this.onConnectedCallback?.();
    });
  }

  private setupConnectionHandlers(conn: DataConnection) {
    conn.on('data', (data) => {
      const msg = data as NetworkMessage;
      if (msg.type === 'ping') {
        conn.send({ type: 'pong' });
        return;
      }
      this.messageHandler?.(msg, conn.peer);
    });

    conn.on('close', () => {
      console.log('Connection closed:', conn.peer);
      this.connections.delete(conn.peer);
      if (!this._isHost && conn === this.hostConnection) {
        this.hostConnection = null;
        this.onDisconnectedCallback?.('Host disconnected');
      } else if (this._isHost) {
        this.messageHandler?.({ type: 'player-left', playerId: conn.peer }, conn.peer);
      }
    });

    conn.on('error', (err) => {
      console.error('Connection error:', err);
    });
  }

  // Send message to host (client only)
  sendToHost(msg: NetworkMessage) {
    if (this.hostConnection?.open) {
      this.hostConnection.send(msg);
    }
  }

  // Send message to specific peer (host only)
  sendToPeer(peerId: string, msg: NetworkMessage) {
    const conn = this.connections.get(peerId);
    if (conn?.open) {
      conn.send(msg);
    }
  }

  // Broadcast message to all connected peers (host only)
  broadcast(msg: NetworkMessage) {
    this.connections.forEach((conn) => {
      if (conn.open) {
        conn.send(msg);
      }
    });
  }

  // Send message (auto-routes based on host/client)
  send(msg: NetworkMessage) {
    if (this._isHost) {
      this.broadcast(msg);
    } else {
      this.sendToHost(msg);
    }
  }

  cleanup() {
    this.connections.forEach((conn) => conn.close());
    this.connections.clear();
    this.hostConnection?.close();
    this.hostConnection = null;
    this.peer?.destroy();
    this.peer = null;
    this._peerId = null;
    this._roomCode = null;
    this._isHost = false;
    this.reconnectAttempts = 0;
  }
}

export const network = new NetworkManager();
