import { create } from 'zustand';
import { v4 as uuidv4 } from 'uuid';
import {
  Player, GameRoom, RoomSettings, BotDifficulty,
  RoundResult, VoteResult,
  BOT_NAMES, BOT_AVATARS,
} from './types';
import type { ChatMessage } from './types';
import { network, NetworkMessage } from './network';
import {
  getBotChatMessages, getBotVoteTarget, getBotKillTarget,
  getBotShieldTargets, createBotChatMessage,
} from './botAI';

interface GameState {
  currentPlayerId: string | null;
  playerName: string;
  playerAvatar: string;
  room: GameRoom | null;
  screen: 'home' | 'create' | 'join' | 'lobby' | 'game' | 'results';
  botDifficulty: BotDifficulty;
  votingTimerRef: ReturnType<typeof setInterval> | null;
  isConnecting: boolean;
  connectionError: string | null;

  setPlayerName: (name: string) => void;
  setPlayerAvatar: (avatar: string) => void;
  setScreen: (screen: GameState['screen']) => void;
  setBotDifficulty: (d: BotDifficulty) => void;

  createRoom: (settings: RoomSettings) => Promise<void>;
  joinRoom: (code: string) => Promise<boolean>;
  addBot: () => void;
  removeBot: (id: string) => void;
  startGame: () => void;

  impostorKill: (impostorId: string, targetId: string) => void;
  impostorDone: (impostorId: string) => void;
  doctorShield: (doctorId: string, targets: string[]) => void;
  doctorDone: (doctorId: string) => void;
  processRound: () => void;

  startVoting: () => void;
  castVote: (voterId: string, targetId: string | 'skip') => void;
  processVotes: () => void;
  nextRound: () => void;
  sendChat: (text: string) => void;

  resetGame: () => void;
  backToLobby: () => void;
  executeBotActions: () => void;
  checkWinCondition: () => boolean;

  // Network
  handleNetworkMessage: (msg: NetworkMessage, fromId: string) => void;
  syncRoomState: () => void;
}

function shuffleArray<T>(array: T[]): T[] {
  const shuffled = [...array];
  for (let i = shuffled.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
  }
  return shuffled;
}

export const useGameStore = create<GameState>((set, get) => {
  // Setup network message handler
  network.setMessageHandler((msg, fromId) => {
    get().handleNetworkMessage(msg, fromId);
  });

  network.onDisconnected((reason) => {
    console.log('Disconnected:', reason);
    set({ connectionError: reason, screen: 'home', room: null });
  });

  network.onError((error) => {
    console.log('Error:', error);
    set({ connectionError: error });
  });

  return {
    currentPlayerId: null,
    playerName: '',
    playerAvatar: '',
    room: null,
    screen: 'home',
    botDifficulty: 3,
    votingTimerRef: null,
    isConnecting: false,
    connectionError: null,

    setPlayerName: (name) => set({ playerName: name }),
    setPlayerAvatar: (avatar) => set({ playerAvatar: avatar }),
    setScreen: (screen) => set({ screen }),
    setBotDifficulty: (d) => set({ botDifficulty: d }),

    handleNetworkMessage: (msg, _fromId) => {
      const { room } = get();

      switch (msg.type) {
        case 'room-state':
          // Client receives full room state from host
          set({ room: msg.room });
          break;

        case 'player-joined':
          if (network.isHost && room) {
            room.players.push(msg.player);
            set({ room: { ...room } });
            get().syncRoomState();
          }
          break;

        case 'player-left':
          if (network.isHost && room) {
            room.players = room.players.filter(p => p.id !== msg.playerId);
            set({ room: { ...room } });
            get().syncRoomState();
          }
          break;

        case 'game-start':
          if (!network.isHost) {
            set({ screen: 'game' });
          }
          break;

        case 'impostor-kill':
          if (network.isHost) {
            get().impostorKill(msg.impostorId, msg.targetId);
          }
          break;

        case 'impostor-done':
          if (network.isHost) {
            get().impostorDone(msg.impostorId);
          }
          break;

        case 'doctor-shield':
          if (network.isHost) {
            get().doctorShield(msg.doctorId, msg.targets);
          }
          break;

        case 'doctor-done':
          if (network.isHost) {
            get().doctorDone(msg.doctorId);
          }
          break;

        case 'chat':
          if (network.isHost && room) {
            room.chatMessages.push(msg.message);
            set({ room: { ...room } });
            get().syncRoomState();
          }
          break;

        case 'vote':
          if (network.isHost) {
            get().castVote(msg.vote.voterId, msg.vote.targetId);
          }
          break;

        case 'next-round':
          if (network.isHost) {
            get().nextRound();
          }
          break;

        case 'reset-game':
          if (network.isHost) {
            get().resetGame();
          }
          break;

        case 'add-bot':
          if (network.isHost) {
            get().addBot();
          }
          break;

        case 'remove-bot':
          if (network.isHost) {
            get().removeBot(msg.botId);
          }
          break;
      }
    },

    syncRoomState: () => {
      const { room } = get();
      if (network.isHost && room) {
        network.broadcast({ type: 'room-state', room });
      }
    },

    createRoom: async (settings) => {
      set({ isConnecting: true, connectionError: null });
      
      try {
        const roomCode = await network.createRoom();
        const playerId = uuidv4();
        
        const player: Player = {
          id: playerId,
          name: get().playerName || 'Player',
          avatar: get().playerAvatar || '😎',
          role: 'innocent',
          isAlive: true,
          isBot: false,
          botDifficulty: 1,
          shields: 0,
          isHost: true,
        };

        const room: GameRoom = {
          id: uuidv4(),
          code: roomCode,
          host: playerId,
          players: [player],
          settings,
          phase: 'lobby',
          round: 0,
          killAttempts: [],
          shieldActions: [],
          roundResults: [],
          votes: [],
          voteResults: [],
          chatMessages: [],
          votingTimeLeft: 60,
          winner: null,
        };

        set({ 
          room, 
          currentPlayerId: playerId, 
          screen: 'lobby',
          isConnecting: false 
        });
      } catch (error) {
        set({ 
          isConnecting: false, 
          connectionError: error instanceof Error ? error.message : 'Failed to create room' 
        });
        throw error;
      }
    },

    joinRoom: async (code) => {
      set({ isConnecting: true, connectionError: null });
      
      try {
        await network.joinRoom(code);
        
        const playerId = uuidv4();
        const player: Player = {
          id: playerId,
          name: get().playerName || 'Player',
          avatar: get().playerAvatar || '😎',
          role: 'innocent',
          isAlive: true,
          isBot: false,
          botDifficulty: 1,
          shields: 0,
          isHost: false,
        };

        // Send join request to host
        network.sendToHost({ type: 'player-joined', player });
        
        set({ 
          currentPlayerId: playerId, 
          screen: 'lobby',
          isConnecting: false 
        });
        
        return true;
      } catch (error) {
        set({ 
          isConnecting: false, 
          connectionError: error instanceof Error ? error.message : 'Failed to join room' 
        });
        return false;
      }
    },

    addBot: () => {
      const { room, botDifficulty } = get();
      if (!room) return;
      if (!network.isHost) {
        network.sendToHost({ type: 'add-bot', difficulty: botDifficulty });
        return;
      }
      if (room.players.length >= room.settings.maxPlayers) return;
      
      const usedNames = room.players.map(p => p.name);
      const availableNames = BOT_NAMES.filter(n => !usedNames.includes(n));
      const botIndex = room.players.filter(p => p.isBot).length;
      
      const bot: Player = {
        id: uuidv4(),
        name: availableNames[0] || `Bot ${botIndex + 1}`,
        avatar: BOT_AVATARS[botIndex % BOT_AVATARS.length],
        role: 'innocent',
        isAlive: true,
        isBot: true,
        botDifficulty,
        shields: 0,
        isHost: false,
      };
      
      room.players.push(bot);
      set({ room: { ...room } });
      get().syncRoomState();
    },

    removeBot: (id) => {
      const { room } = get();
      if (!room) return;
      if (!network.isHost) {
        network.sendToHost({ type: 'remove-bot', botId: id });
        return;
      }
      
      room.players = room.players.filter(p => p.id !== id);
      set({ room: { ...room } });
      get().syncRoomState();
    },

    startGame: () => {
      const { room } = get();
      if (!room || !network.isHost) return;
      
      const totalPlayers = room.players.length;
      if (totalPlayers < 3) return;

      const shuffledIndices = shuffleArray([...Array(totalPlayers).keys()]);
      const impostorIndices = shuffledIndices.slice(0, room.settings.impostorCount);
      const doctorIndices = shuffledIndices.slice(
        room.settings.impostorCount,
        room.settings.impostorCount + room.settings.doctorCount
      );

      room.players.forEach((player, idx) => {
        if (impostorIndices.includes(idx)) player.role = 'impostor';
        else if (doctorIndices.includes(idx)) player.role = 'doctor';
        else player.role = 'innocent';
        player.isAlive = true;
        player.shields = 0;
      });

      room.phase = 'night-start';
      room.round = 1;
      room.killAttempts = [];
      room.shieldActions = [];
      room.roundResults = [];
      room.votes = [];
      room.voteResults = [];
      room.chatMessages = [];
      room.votingTimeLeft = 60;
      room.winner = null;

      set({ room: { ...room }, screen: 'game' });
      network.broadcast({ type: 'game-start' });
      get().syncRoomState();

      setTimeout(() => {
        const currentRoom = get().room;
        if (currentRoom && currentRoom.phase === 'night-start') {
          currentRoom.phase = 'impostor-turn';
          currentRoom.killAttempts = [];
          set({ room: { ...currentRoom } });
          get().syncRoomState();
          setTimeout(() => get().executeBotActions(), 1500);
        }
      }, 5000);
    },

    impostorKill: (impostorId, targetId) => {
      const { room } = get();
      if (!room || room.phase !== 'impostor-turn') return;
      
      if (!network.isHost) {
        network.sendToHost({ type: 'impostor-kill', impostorId, targetId });
        return;
      }
      
      room.killAttempts = room.killAttempts.filter(k => k.impostorId !== impostorId);
      room.killAttempts.push({ impostorId, targetId });
      set({ room: { ...room } });
      get().syncRoomState();
    },

    impostorDone: (impostorId) => {
      const { room } = get();
      if (!room) return;
      
      if (!network.isHost) {
        network.sendToHost({ type: 'impostor-done', impostorId });
        return;
      }
      
      const aliveImpostors = room.players.filter(p => p.role === 'impostor' && p.isAlive);
      const killsMade = room.killAttempts.length;

      if (killsMade >= aliveImpostors.length) {
        const aliveDoctors = room.players.filter(p => p.role === 'doctor' && p.isAlive);
        if (aliveDoctors.length === 0) {
          get().processRound();
          return;
        }
        room.phase = 'doctor-turn';
        room.shieldActions = [];
        set({ room: { ...room } });
        get().syncRoomState();
        setTimeout(() => get().executeBotActions(), 1500);
      }
    },

    doctorShield: (doctorId, targets) => {
      const { room } = get();
      if (!room || room.phase !== 'doctor-turn') return;
      
      if (!network.isHost) {
        network.sendToHost({ type: 'doctor-shield', doctorId, targets });
        return;
      }
      
      room.shieldActions = room.shieldActions.filter(s => s.doctorId !== doctorId);
      const shieldsEach = targets.length === 1 ? 2 : 1;
      room.shieldActions.push({ doctorId, targets, shieldsEach });
      set({ room: { ...room } });
      get().syncRoomState();
    },

    doctorDone: (doctorId) => {
      const { room } = get();
      if (!room) return;
      
      if (!network.isHost) {
        network.sendToHost({ type: 'doctor-done', doctorId });
        return;
      }
      
      const aliveDoctors = room.players.filter(p => p.role === 'doctor' && p.isAlive);
      const shieldsMade = room.shieldActions.length;
      if (shieldsMade >= aliveDoctors.length) {
        get().processRound();
      }
    },

    processRound: () => {
      const { room } = get();
      if (!room || !network.isHost) return;

      const roundResult: RoundResult = { round: room.round, kills: [], shields: [] };

      room.shieldActions.forEach(action => {
        action.targets.forEach(targetId => {
          const player = room.players.find(p => p.id === targetId);
          if (player && player.isAlive) {
            const newShields = Math.min(player.shields + action.shieldsEach, 5);
            const added = newShields - player.shields;
            player.shields = newShields;
            if (added > 0) {
              roundResult.shields.push({ targetId: player.id, targetName: player.name, amount: added });
            }
          }
        });
      });

      room.killAttempts.forEach(attempt => {
        const target = room.players.find(p => p.id === attempt.targetId);
        if (target && target.isAlive) {
          if (target.shields > 0) {
            target.shields -= 1;
            roundResult.kills.push({ targetId: target.id, targetName: target.name, blocked: true });
          } else {
            target.isAlive = false;
            roundResult.kills.push({ targetId: target.id, targetName: target.name, blocked: false });
          }
        }
      });

      room.roundResults.push(roundResult);
      room.phase = 'reveal';

      if (get().checkWinCondition()) return;
      set({ room: { ...room } });
      get().syncRoomState();
    },

    checkWinCondition: () => {
      const { room } = get();
      if (!room) return false;
      
      const alivePlayers = room.players.filter(p => p.isAlive);
      const aliveImpostors = alivePlayers.filter(p => p.role === 'impostor');
      const aliveInnocents = alivePlayers.filter(p => p.role !== 'impostor');

      if (aliveImpostors.length === 0) {
        room.winner = 'innocents';
        room.phase = 'game-over';
        set({ room: { ...room } });
        if (network.isHost) get().syncRoomState();
        return true;
      } else if (aliveInnocents.length <= 1) {
        room.winner = 'impostor';
        room.phase = 'game-over';
        set({ room: { ...room } });
        if (network.isHost) get().syncRoomState();
        return true;
      }
      return false;
    },

    startVoting: () => {
      const { room } = get();
      if (!room || !network.isHost) return;

      room.phase = 'voting';
      room.votes = [];
      room.chatMessages = [];
      room.votingTimeLeft = 60;
      set({ room: { ...room } });
      get().syncRoomState();

      const oldRef = get().votingTimerRef;
      if (oldRef) clearInterval(oldRef);

      const timerRef = setInterval(() => {
        const r = get().room;
        if (!r || r.phase !== 'voting') {
          clearInterval(timerRef);
          set({ votingTimerRef: null });
          return;
        }
        r.votingTimeLeft -= 1;
        if (r.votingTimeLeft <= 0) {
          clearInterval(timerRef);
          set({ votingTimerRef: null });
          const alivePlayers = r.players.filter(p => p.isAlive);
          alivePlayers.forEach(p => {
            if (!r.votes.some(v => v.voterId === p.id)) {
              r.votes.push({ voterId: p.id, targetId: 'skip' });
            }
          });
          set({ room: { ...r } });
          get().syncRoomState();
          setTimeout(() => get().processVotes(), 500);
          return;
        }
        set({ room: { ...r } });
        get().syncRoomState();
      }, 1000);

      set({ votingTimerRef: timerRef });

      // Bot AI
      const aliveBots = room.players.filter(p => p.isBot && p.isAlive);
      const alivePlayers = room.players.filter(p => p.isAlive);

      aliveBots.forEach((bot, i) => {
        const difficulty = bot.botDifficulty;
        const chatCount = Math.min(difficulty, 3);
        
        for (let c = 0; c < chatCount; c++) {
          const chatDelay = 2000 + Math.random() * 15000 + c * 8000;
          setTimeout(() => {
            const r = get().room;
            if (!r || r.phase !== 'voting') return;
            const messages = getBotChatMessages(bot, alivePlayers, r.chatMessages, difficulty, r.round);
            if (messages[c]) {
              r.chatMessages.push(createBotChatMessage(bot, messages[c]));
              set({ room: { ...r } });
              get().syncRoomState();
            }
          }, chatDelay);
        }

        const voteDelay = 10000 + Math.random() * 40000 + i * 3000;
        setTimeout(() => {
          const r = get().room;
          if (!r || r.phase !== 'voting') return;
          if (r.votes.some(v => v.voterId === bot.id)) return;
          const targetId = getBotVoteTarget(bot, alivePlayers, r.chatMessages, difficulty);
          get().castVote(bot.id, targetId);
        }, voteDelay);
      });
    },

    castVote: (voterId, targetId) => {
      const { room, currentPlayerId } = get();
      if (!room || room.phase !== 'voting') return;
      
      if (!network.isHost && voterId === currentPlayerId) {
        network.sendToHost({ type: 'vote', vote: { voterId, targetId } });
        return;
      }
      
      if (!network.isHost) return;
      
      if (room.votes.some(v => v.voterId === voterId)) return;
      room.votes.push({ voterId, targetId });
      set({ room: { ...room } });
      get().syncRoomState();

      const alivePlayers = room.players.filter(p => p.isAlive);
      if (room.votes.length >= alivePlayers.length) {
        const ref = get().votingTimerRef;
        if (ref) { clearInterval(ref); set({ votingTimerRef: null }); }
        setTimeout(() => get().processVotes(), 1000);
      }
    },

    processVotes: () => {
      const { room } = get();
      if (!room || room.phase !== 'voting' || !network.isHost) return;

      const tally: Map<string, number> = new Map();
      let skipCount = 0;
      room.votes.forEach(v => {
        if (v.targetId === 'skip') skipCount++;
        else tally.set(v.targetId, (tally.get(v.targetId) || 0) + 1);
      });

      let maxVotes = skipCount;
      let maxId: string | null = null;
      let isTie = false;

      tally.forEach((count, id) => {
        if (count > maxVotes) {
          maxVotes = count;
          maxId = id;
          isTie = false;
        } else if (count === maxVotes && maxId !== null) {
          isTie = true;
        }
      });

      if (maxId === null || isTie) {
        const result: VoteResult = {
          round: room.round, votes: [...room.votes],
          ejectedId: null, ejectedName: null, wasImpostor: null, isTie,
        };
        room.voteResults.push(result);
        room.phase = 'vote-result';
        set({ room: { ...room } });
        get().syncRoomState();
      } else {
        const ejected = room.players.find(p => p.id === maxId);
        if (ejected) {
          ejected.isAlive = false;
          const result: VoteResult = {
            round: room.round, votes: [...room.votes],
            ejectedId: ejected.id, ejectedName: ejected.name,
            wasImpostor: ejected.role === 'impostor', isTie: false,
          };
          room.voteResults.push(result);
          room.phase = 'vote-result';
        }
        set({ room: { ...room } });
        get().syncRoomState();
      }
    },

    sendChat: (text) => {
      const { room, currentPlayerId } = get();
      if (!room || room.phase !== 'voting') return;
      const player = room.players.find(p => p.id === currentPlayerId);
      if (!player || !player.isAlive) return;

      const msg: ChatMessage = {
        id: uuidv4(),
        playerId: player.id,
        playerName: player.name,
        playerAvatar: player.avatar,
        text: text.trim().slice(0, 200),
        timestamp: Date.now(),
      };
      
      if (network.isHost) {
        room.chatMessages.push(msg);
        set({ room: { ...room } });
        get().syncRoomState();
      } else {
        network.sendToHost({ type: 'chat', message: msg });
      }
    },

    nextRound: () => {
      const { room } = get();
      if (!room) return;
      
      if (!network.isHost) {
        network.sendToHost({ type: 'next-round' });
        return;
      }
      
      if (get().checkWinCondition()) return;

      room.round += 1;
      room.phase = 'night-start';
      room.killAttempts = [];
      room.shieldActions = [];
      room.votes = [];
      room.chatMessages = [];
      room.votingTimeLeft = 60;

      set({ room: { ...room } });
      get().syncRoomState();

      setTimeout(() => {
        const currentRoom = get().room;
        if (currentRoom && currentRoom.phase === 'night-start') {
          currentRoom.phase = 'impostor-turn';
          currentRoom.killAttempts = [];
          set({ room: { ...currentRoom } });
          get().syncRoomState();
          setTimeout(() => get().executeBotActions(), 1500);
        }
      }, 5000);
    },

    executeBotActions: () => {
      const { room } = get();
      if (!room || !network.isHost) return;

      if (room.phase === 'impostor-turn') {
        const botImpostors = room.players.filter(p => p.role === 'impostor' && p.isBot && p.isAlive);
        const alivePlayers = room.players.filter(p => p.isAlive);
        
        botImpostors.forEach(bot => {
          const targetId = getBotKillTarget(bot, alivePlayers, room.roundResults, bot.botDifficulty);
          if (targetId) get().impostorKill(bot.id, targetId);
        });

        const aliveImpostors = room.players.filter(p => p.role === 'impostor' && p.isAlive);
        const humanImpostors = aliveImpostors.filter(p => !p.isBot);
        if (humanImpostors.length === 0) {
          setTimeout(() => get().impostorDone('bot'), 1000);
        }
      } else if (room.phase === 'doctor-turn') {
        const botDoctors = room.players.filter(p => p.role === 'doctor' && p.isBot && p.isAlive);
        const alivePlayers = room.players.filter(p => p.isAlive);
        
        botDoctors.forEach(bot => {
          const targets = getBotShieldTargets(bot, alivePlayers, room.roundResults, bot.botDifficulty);
          if (targets.length > 0) get().doctorShield(bot.id, targets);
        });

        const aliveDoctors = room.players.filter(p => p.role === 'doctor' && p.isAlive);
        const humanDoctors = aliveDoctors.filter(p => !p.isBot);
        if (humanDoctors.length === 0) {
          setTimeout(() => get().doctorDone('bot'), 1000);
        }
      }
    },

    resetGame: () => {
      const { room, votingTimerRef } = get();
      if (votingTimerRef) clearInterval(votingTimerRef);
      if (!room) return;
      
      if (!network.isHost) {
        network.sendToHost({ type: 'reset-game' });
        return;
      }
      
      room.phase = 'lobby';
      room.round = 0;
      room.killAttempts = [];
      room.shieldActions = [];
      room.roundResults = [];
      room.votes = [];
      room.voteResults = [];
      room.chatMessages = [];
      room.votingTimeLeft = 60;
      room.winner = null;
      room.players.forEach(p => {
        p.role = 'innocent';
        p.isAlive = true;
        p.shields = 0;
      });
      set({ room: { ...room }, screen: 'lobby', votingTimerRef: null });
      get().syncRoomState();
    },

    backToLobby: () => {
      const { votingTimerRef } = get();
      if (votingTimerRef) clearInterval(votingTimerRef);
      network.cleanup();
      set({ room: null, screen: 'home', votingTimerRef: null, connectionError: null });
    },
  };
});
