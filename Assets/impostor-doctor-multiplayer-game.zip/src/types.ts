export type Role = 'impostor' | 'doctor' | 'innocent';
export type GamePhase = 'lobby' | 'night-start' | 'impostor-turn' | 'doctor-turn' | 'reveal' | 'voting' | 'vote-result' | 'game-over';

export type BotDifficulty = 1 | 2 | 3 | 4 | 5;

export interface Player {
  id: string;
  name: string;
  avatar: string; // base64 or URL
  role: Role;
  isAlive: boolean;
  isBot: boolean;
  botDifficulty: BotDifficulty; // 1=easy, 5=expert
  shields: number;
  isHost: boolean;
}

export interface KillAttempt {
  impostorId: string;
  targetId: string;
}

export interface ShieldAction {
  doctorId: string;
  targets: string[]; // 1 or 2 player IDs
  shieldsEach: number; // 2 if 1 target, 1 if 2 targets
}

export interface RoomSettings {
  maxPlayers: number;
  impostorCount: number;
  doctorCount: number;
}

export interface ChatMessage {
  id: string;
  playerId: string;
  playerName: string;
  playerAvatar: string;
  text: string;
  timestamp: number;
}

export interface Vote {
  voterId: string;
  targetId: string | 'skip'; // player id or 'skip'
}

export interface VoteResult {
  round: number;
  votes: Vote[];
  ejectedId: string | null; // null if skipped or tie
  ejectedName: string | null;
  wasImpostor: boolean | null;
  isTie: boolean;
}

export interface GameRoom {
  id: string;
  code: string;
  host: string;
  players: Player[];
  settings: RoomSettings;
  phase: GamePhase;
  round: number;
  killAttempts: KillAttempt[];
  shieldActions: ShieldAction[];
  roundResults: RoundResult[];
  votes: Vote[];
  voteResults: VoteResult[];
  chatMessages: ChatMessage[];
  votingTimeLeft: number;
  winner: 'impostor' | 'innocents' | null;
}

export interface RoundResult {
  round: number;
  kills: { targetId: string; targetName: string; blocked: boolean }[];
  shields: { targetId: string; targetName: string; amount: number }[];
}

// Bot names
export const BOT_NAMES = [
  'Shadow', 'Phantom', 'Ghost', 'Specter', 'Wraith',
  'Eclipse', 'Nova', 'Raven', 'Storm', 'Blaze',
  'Viper', 'Frost', 'Thunder', 'Mystic', 'Cipher',
  'Nebula', 'Onyx', 'Cobra', 'Phoenix', 'Apex'
];

export const BOT_AVATARS = [
  '🤖', '👾', '🎭', '🦊', '🐺', '🦅', '🐲', '🦁', '🐙', '🦇',
  '🐍', '❄️', '⚡', '🔮', '🎯', '🌌', '💎', '🐉', '🔥', '⭐'
];

// Bot chat messages for slandering / defending
export const BOT_CHAT_ACCUSE = [
  "I think {name} is acting suspicious...",
  "{name} seems quiet, kinda sus 🤔",
  "Anyone else notice {name} being weird?",
  "I'm voting for {name}, they're definitely the impostor",
  "It has to be {name}. I have a feeling.",
  "{name} was acting strange last round",
  "I don't trust {name} at all",
  "Why is {name} so quiet? Very sus.",
  "I saw {name} do something weird 👀",
  "{name} is definitely hiding something!",
];

export const BOT_CHAT_DEFEND = [
  "It's not me, I promise!",
  "I'm innocent, vote someone else!",
  "Why would you vote me? I'm clearly not the impostor.",
  "Trust me, I'm on your side!",
  "I've been helping the whole time 😤",
  "You're making a mistake if you vote me",
  "Look at the evidence, it's not me",
  "I swear on my life it's not me!",
];

export const BOT_CHAT_GENERIC = [
  "Who do we think it is?",
  "Let's think about this carefully...",
  "I'm not sure who to vote for",
  "This is tough, anyone have ideas?",
  "We need to figure this out 🤔",
  "Let's vote wisely, we can't afford mistakes",
  "I think we should skip if we're not sure",
  "Does anyone have any clues?",
];
