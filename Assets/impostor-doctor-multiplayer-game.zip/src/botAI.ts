import { Player, ChatMessage } from './types';
import { v4 as uuidv4 } from 'uuid';

export type BotDifficulty = 1 | 2 | 3 | 4 | 5;

// ============ BOT CHAT MESSAGES ============
// Level 1-2: Simple messages
const CHAT_SIMPLE_ACCUSE = [
  "I think {name} is sus",
  "{name} looks suspicious",
  "Vote {name}?",
  "It's {name} I think",
  "Idk but maybe {name}",
];

const CHAT_SIMPLE_DEFEND = [
  "It's not me!",
  "I'm innocent",
  "Why me??",
  "Not me, vote someone else",
  "I swear I'm not the impostor",
];

const CHAT_SIMPLE_GENERIC = [
  "Who is it?",
  "Idk",
  "hmm",
  "???",
  "Anyone have ideas?",
];

// Level 3-4: More natural messages
const CHAT_MEDIUM_ACCUSE = [
  "I've been watching {name} and something feels off about them...",
  "{name} has been really quiet, that's always suspicious to me",
  "Not gonna lie, {name} gives me bad vibes this round",
  "Anyone else notice {name} acting weird? Just me?",
  "I'm getting impostor energy from {name} tbh",
  "The way {name} is playing... I don't trust it",
  "{name} seemed nervous during the reveal, did anyone else see that?",
  "My gut says {name}. Could be wrong but that's my read",
  "I've been thinking about it and {name} makes the most sense",
  "{name} hasn't said anything useful, kinda sus ngl",
];

const CHAT_MEDIUM_DEFEND = [
  "Guys I promise it's not me, I've been playing clean",
  "Why would I do that if I was the impostor? Think about it",
  "I'm literally just trying to survive here, not the impostor",
  "You're wasting a vote on me, the real impostor is still out there",
  "I've been helping figure this out, why would you vote me?",
  "Come on, use logic here. It doesn't make sense for it to be me",
  "If I was the impostor I would've won by now lol",
  "I'm getting blamed for no reason, look at the actual evidence",
];

const CHAT_MEDIUM_GENERIC = [
  "Let's think about this carefully before we vote",
  "We can't afford to vote wrong here",
  "Does anyone have actual evidence or are we just guessing?",
  "I feel like we're missing something obvious",
  "We should consider who benefits from voting {name}",
  "What's everyone thinking? I wanna hear other opinions",
  "Maybe we should skip if we're not sure?",
  "This is a tough one, could go either way",
  "Let's not rush this decision",
  "Who do you all think it is? I'm torn",
];

const CHAT_MEDIUM_ANALYSIS = [
  "Wait, if {name} was the impostor, why would they {action}?",
  "Think about last round - {name} was acting normal, but {name2} wasn't",
  "The kill pattern suggests someone smart, that could be {name}",
  "Notice how {name} only speaks up when they're accused? Classic deflection",
  "{name} voted with me last round, could be trying to gain trust",
  "The doctor has been saving someone consistently, wonder who...",
  "Whoever the impostor is, they're playing it safe",
  "We need to think about who would benefit from voting {name}",
];

// Level 5: Expert messages with reasoning
const CHAT_EXPERT_ACCUSE = [
  "I've analyzed the voting patterns and {name} has been consistently voting against innocents",
  "{name}'s behavior changed after round {round}, that's when I started suspecting them",
  "Notice how {name} always has an alibi ready? That level of preparation is suspicious",
  "The impostor has been playing conservatively, and {name} fits that profile perfectly",
  "{name} tried to shift blame onto someone who got saved by shields - they knew that person was being targeted",
  "Statistical analysis: {name} has voted against players who died 80% of the time. Too coincidental.",
  "I noticed {name} started defending themselves before anyone even accused them. Guilty conscience?",
  "{name} has been building alliances with potential targets. Classic impostor strategy to avoid suspicion.",
];

const CHAT_EXPERT_DEFEND = [
  "If you actually analyze my voting record, I've been consistent with my suspicions the whole game",
  "Think about it logically - if I were the impostor, would I draw attention to myself like this?",
  "I understand the suspicion, but consider: who benefits if you vote me out? The real impostor.",
  "My behavior has been transparent. The impostor would be more careful about appearing innocent.",
  "Check the history - every player I've defended has been innocent. That's not an impostor pattern.",
  "You're being manipulated into voting me. Step back and think about who pushed this narrative.",
];

const CHAT_EXPERT_STRATEGY = [
  "Based on the kill attempts and saves, I think the doctor has been protecting {name} - they might know something",
  "The impostor has avoided killing {name} twice now. Either {name} is the impostor or the impostor wants us to think that",
  "Let's think about information asymmetry - who would know things they shouldn't?",
  "The voting coalition of {name} and {name2} is interesting. Either they're both innocent or one is manipulating the other",
  "We should consider: if we vote wrong here, the impostor wins next round. Let's be certain.",
  "The shield patterns suggest the doctor suspects {name}. That's valuable information.",
  "Statistically, voting randomly gives the impostor a {percent}% win chance. We need to do better.",
];

const CHAT_EXPERT_DISCUSSION = [
  "I agree with {name}'s analysis, but there's another angle we're not considering...",
  "That's a good point, {name}. But have you thought about {counterpoint}?",
  "Building on what {name} said, I think the pattern actually suggests...",
  "{name} makes a compelling argument, but I'm not fully convinced yet",
  "I see where {name} is coming from, and I think they might be onto something",
  "Let me push back on that - if {name}'s theory is correct, then why would...",
  "Hold on, {name} - what evidence do you actually have for that?",
  "I was thinking the same thing as {name}, we should follow that lead",
  "Wait wait wait... {name} might be onto something big here",
  "@{name} explain your reasoning? I want to understand your logic",
];

// Additional human-like reactions
const CHAT_REACTIONS = [
  "Yo wait what 😳",
  "That's wild lol",
  "Fr fr",
  "No way bruh",
  "lmaooo",
  "sus af",
  "Agreed 👆",
  "This 💯",
  "Nah that ain't it",
  "Hmmm interesting...",
  "Wait hold up",
  "💀💀💀",
  "Good point actually",
  "I didn't think of that",
  "Big brain energy",
  "That makes sense",
  "True true",
  "Facts",
  "Oof",
  "Bruh moment",
];

const CHAT_GREETINGS = [
  "gg everyone",
  "Alright let's figure this out",
  "What we thinking team?",
  "Okay so what happened last night",
  "Anyone see anything?",
  "Let's discuss",
  "Here we go again lol",
  "Round {round} let's goooo",
];

// ============ BOT AI FUNCTIONS ============

export function getBotChatMessages(
  bot: Player,
  alivePlayers: Player[],
  chatHistory: ChatMessage[],
  difficulty: BotDifficulty,
  round: number
): string[] {
  const messages: string[] = [];
  const others = alivePlayers.filter(p => p.id !== bot.id);
  const nonImpostors = others.filter(p => p.role !== 'impostor');
  const randomPlayer = others[Math.floor(Math.random() * others.length)];

  // Number of messages based on difficulty
  const messageCount = Math.min(difficulty, 3);

  for (let i = 0; i < messageCount; i++) {
    let msg = '';
    const roll = Math.random();

    if (bot.role === 'impostor') {
      // Impostor bot: try to frame innocents
      const target = nonImpostors.length > 0 
        ? nonImpostors[Math.floor(Math.random() * nonImpostors.length)]
        : randomPlayer;

      if (difficulty <= 2) {
        msg = pickRandom(CHAT_SIMPLE_ACCUSE).replace('{name}', target?.name || 'someone');
      } else if (difficulty <= 4) {
        if (roll < 0.6) {
          msg = pickRandom(CHAT_MEDIUM_ACCUSE).replace('{name}', target?.name || 'someone');
        } else {
          msg = pickRandom(CHAT_MEDIUM_GENERIC).replace('{name}', target?.name || 'someone');
        }
      } else {
        // Level 5: Expert manipulation
        if (roll < 0.4) {
          msg = pickRandom(CHAT_EXPERT_ACCUSE)
            .replace('{name}', target?.name || 'someone')
            .replace('{round}', String(Math.max(1, round - 1)));
        } else if (roll < 0.7) {
          msg = pickRandom(CHAT_EXPERT_STRATEGY)
            .replace('{name}', target?.name || 'someone')
            .replace('{name2}', randomPlayer?.name || 'someone')
            .replace('{percent}', String(Math.round(100 / Math.max(1, alivePlayers.length))));
        } else {
          // Respond to recent chat
          if (chatHistory.length > 0) {
            const recent = chatHistory[chatHistory.length - 1];
            msg = pickRandom(CHAT_EXPERT_DISCUSSION)
              .replace('{name}', recent.playerName)
              .replace('{counterpoint}', 'the timing doesn\'t add up');
          } else {
            msg = pickRandom(CHAT_MEDIUM_GENERIC).replace('{name}', target?.name || 'someone');
          }
        }
      }
    } else {
      // Non-impostor bot: try to find impostor or defend
      const beingAccused = chatHistory.some(
        m => m.text.toLowerCase().includes(bot.name.toLowerCase()) && 
             (m.text.includes('sus') || m.text.includes('vote') || m.text.includes('think'))
      );

      if (beingAccused && roll < 0.7) {
        // Defend self
        if (difficulty <= 2) {
          msg = pickRandom(CHAT_SIMPLE_DEFEND);
        } else if (difficulty <= 4) {
          msg = pickRandom(CHAT_MEDIUM_DEFEND);
        } else {
          msg = pickRandom(CHAT_EXPERT_DEFEND);
        }
      } else if (roll < 0.5) {
        // Accuse someone randomly (they don't know who impostor is)
        if (difficulty <= 2) {
          msg = pickRandom(CHAT_SIMPLE_ACCUSE).replace('{name}', randomPlayer?.name || 'someone');
        } else if (difficulty <= 4) {
          msg = pickRandom(CHAT_MEDIUM_ACCUSE).replace('{name}', randomPlayer?.name || 'someone');
        } else {
          // Level 5: Try to analyze
          msg = pickRandom([...CHAT_EXPERT_ACCUSE, ...CHAT_MEDIUM_ANALYSIS])
            .replace('{name}', randomPlayer?.name || 'someone')
            .replace('{name2}', others[Math.floor(Math.random() * others.length)]?.name || 'someone')
            .replace('{action}', 'stay so quiet')
            .replace('{round}', String(Math.max(1, round - 1)));
        }
      } else {
        // Generic discussion / reactions
        if (difficulty <= 2) {
          msg = pickRandom(CHAT_SIMPLE_GENERIC);
        } else if (difficulty <= 4) {
          // Sometimes react to recent messages
          if (chatHistory.length > 0 && Math.random() > 0.6) {
            msg = pickRandom(CHAT_REACTIONS);
          } else if (i === 0 && Math.random() > 0.7) {
            msg = pickRandom(CHAT_GREETINGS).replace('{round}', String(round));
          } else {
            msg = pickRandom(CHAT_MEDIUM_GENERIC).replace('{name}', randomPlayer?.name || 'someone');
          }
        } else {
          // Level 5: Engage with discussion
          if (chatHistory.length > 0 && Math.random() > 0.3) {
            const recent = chatHistory[chatHistory.length - 1];
            // Sometimes just react
            if (Math.random() > 0.5) {
              msg = pickRandom(CHAT_REACTIONS);
            } else {
              msg = pickRandom(CHAT_EXPERT_DISCUSSION)
                .replace('{name}', recent.playerName)
                .replace('{counterpoint}', 'we should look at the bigger picture');
            }
          } else if (i === 0 && Math.random() > 0.5) {
            msg = pickRandom(CHAT_GREETINGS).replace('{round}', String(round));
          } else {
            msg = pickRandom([...CHAT_EXPERT_STRATEGY, ...CHAT_MEDIUM_GENERIC])
              .replace('{name}', randomPlayer?.name || 'someone')
              .replace('{name2}', others[Math.floor(Math.random() * others.length)]?.name || 'someone')
              .replace('{percent}', String(Math.round(100 / Math.max(1, alivePlayers.length))));
          }
        }
      }
    }

    if (msg && !messages.includes(msg)) {
      messages.push(msg);
    }
  }

  return messages;
}

export function getBotVoteTarget(
  bot: Player,
  alivePlayers: Player[],
  chatHistory: ChatMessage[],
  difficulty: BotDifficulty
): string | 'skip' {
  const others = alivePlayers.filter(p => p.id !== bot.id);
  const nonImpostors = others.filter(p => p.role !== 'impostor');
  const impostors = others.filter(p => p.role === 'impostor');

  if (bot.role === 'impostor') {
    // Impostor votes for non-impostors
    // Higher difficulty = more strategic targeting
    if (difficulty >= 4 && nonImpostors.length > 0) {
      // Target whoever is being accused most in chat (to blend in)
      const accusations = new Map<string, number>();
      chatHistory.forEach(msg => {
        nonImpostors.forEach(p => {
          if (msg.text.toLowerCase().includes(p.name.toLowerCase())) {
            accusations.set(p.id, (accusations.get(p.id) || 0) + 1);
          }
        });
      });
      
      let maxAccusedId: string | null = null;
      let maxCount = 0;
      accusations.forEach((count, id) => {
        if (count > maxCount) {
          maxCount = count;
          maxAccusedId = id;
        }
      });
      
      if (maxAccusedId) return maxAccusedId;
    }
    
    // Default: random non-impostor
    return nonImpostors.length > 0 
      ? nonImpostors[Math.floor(Math.random() * nonImpostors.length)].id 
      : 'skip';
  } else {
    // Non-impostor voting logic
    const skipChance = difficulty === 1 ? 0.3 : difficulty === 2 ? 0.2 : 0.1;
    
    if (Math.random() < skipChance) {
      return 'skip';
    }

    // Higher difficulty = better at finding impostor through analysis
    if (difficulty >= 4) {
      // Analyze chat for suspicious behavior
      const suspicionScores = new Map<string, number>();
      others.forEach(p => suspicionScores.set(p.id, 0));

      chatHistory.forEach(msg => {
        // Players who accuse a lot might be deflecting
        const accuser = others.find(p => p.id === msg.playerId);
        if (accuser) {
          const accuseCount = (msg.text.match(/sus|suspicious|vote|impostor|think it's/gi) || []).length;
          suspicionScores.set(accuser.id, (suspicionScores.get(accuser.id) || 0) + accuseCount * 0.5);
        }
      });

      // Level 5: Small chance to correctly identify impostor through "intuition"
      if (difficulty === 5 && impostors.length > 0 && Math.random() < 0.4) {
        return impostors[Math.floor(Math.random() * impostors.length)].id;
      }

      // Vote for most suspicious
      let mostSus: string | null = null;
      let maxScore = 0;
      suspicionScores.forEach((score, id) => {
        if (score > maxScore && id !== bot.id) {
          maxScore = score;
          mostSus = id;
        }
      });

      if (mostSus && maxScore > 0) return mostSus;
    }

    // Default: random vote
    return others.length > 0 
      ? others[Math.floor(Math.random() * others.length)].id 
      : 'skip';
  }
}

export function getBotKillTarget(
  _bot: Player,
  alivePlayers: Player[],
  roundResults: { kills: { targetId: string; blocked: boolean }[] }[],
  difficulty: BotDifficulty
): string | null {
  const targets = alivePlayers.filter(p => p.role !== 'impostor' && p.isAlive);
  if (targets.length === 0) return null;

  // Level 1-2: Random target
  if (difficulty <= 2) {
    return targets[Math.floor(Math.random() * targets.length)].id;
  }

  // Level 3-4: Avoid players who have been saved (they might have shields)
  if (difficulty >= 3) {
    const savedPlayers = new Set<string>();
    roundResults.forEach(r => {
      r.kills.forEach(k => {
        if (k.blocked) savedPlayers.add(k.targetId);
      });
    });

    const unsavedTargets = targets.filter(t => !savedPlayers.has(t.id));
    if (unsavedTargets.length > 0) {
      return unsavedTargets[Math.floor(Math.random() * unsavedTargets.length)].id;
    }
  }

  // Level 5: Target doctors first (if identifiable through behavior)
  if (difficulty === 5) {
    const doctors = targets.filter(t => t.role === 'doctor');
    if (doctors.length > 0 && Math.random() < 0.6) {
      return doctors[Math.floor(Math.random() * doctors.length)].id;
    }
  }

  return targets[Math.floor(Math.random() * targets.length)].id;
}

export function getBotShieldTargets(
  bot: Player,
  alivePlayers: Player[],
  roundResults: { kills: { targetId: string; blocked: boolean }[] }[],
  difficulty: BotDifficulty
): string[] {
  const targets = alivePlayers.filter(p => p.isAlive);
  if (targets.length === 0) return [];

  // Level 1-2: Random shielding
  if (difficulty <= 2) {
    const shieldTwo = Math.random() > 0.5 && targets.length > 1;
    if (shieldTwo) {
      const shuffled = [...targets].sort(() => Math.random() - 0.5);
      return [shuffled[0].id, shuffled[1].id];
    }
    return [targets[Math.floor(Math.random() * targets.length)].id];
  }

  // Level 3-4: Protect players who were targeted before
  if (difficulty >= 3) {
    const previousTargets: string[] = [];
    roundResults.forEach(r => {
      r.kills.forEach(k => {
        if (!k.blocked) previousTargets.push(k.targetId);
      });
    });

    // Players who haven't been targeted yet might be next
    const notTargeted = targets.filter(t => 
      !previousTargets.includes(t.id) && t.id !== bot.id
    );

    if (notTargeted.length > 0 && Math.random() < 0.6) {
      const target = notTargeted[Math.floor(Math.random() * notTargeted.length)];
      return [target.id];
    }
  }

  // Level 5: Try to predict impostor's target
  if (difficulty === 5) {
    // Protect non-impostors, especially those speaking up
    const nonImpostors = targets.filter(t => t.role !== 'impostor' && t.id !== bot.id);
    if (nonImpostors.length > 0 && Math.random() < 0.7) {
      // Give 2 shields to 1 vulnerable player
      const protectTarget = nonImpostors[Math.floor(Math.random() * nonImpostors.length)];
      return [protectTarget.id];
    }
  }

  // Default: split shields between 2 players
  if (targets.length > 1 && Math.random() > 0.4) {
    const shuffled = [...targets].sort(() => Math.random() - 0.5);
    return [shuffled[0].id, shuffled[1].id];
  }

  return [targets[Math.floor(Math.random() * targets.length)].id];
}

function pickRandom<T>(arr: T[]): T {
  return arr[Math.floor(Math.random() * arr.length)];
}

export function createBotChatMessage(
  bot: Player,
  text: string
): ChatMessage {
  return {
    id: uuidv4(),
    playerId: bot.id,
    playerName: bot.name,
    playerAvatar: bot.avatar,
    text,
    timestamp: Date.now(),
  };
}
