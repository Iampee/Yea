import { useState, useEffect, useCallback } from 'react';
import { useGameStore } from '../store';
import confetti from 'canvas-confetti';
import { playKillSound, playShieldSound, playRevealSound } from '../sounds';

export default function RevealPhase() {
  const { room, currentPlayerId, startVoting } = useGameStore();
  const [revealStep, setRevealStep] = useState(0);
  const [showResults, setShowResults] = useState(false);

  if (!room) return null;

  const latestResult = room.roundResults[room.roundResults.length - 1];
  if (!latestResult) return null;

  const kills = latestResult.kills;
  const totalSteps = kills.length + 1;

  const fireDeathEffect = useCallback(() => {
    confetti({
      particleCount: 80, spread: 100, origin: { y: 0.5 },
      colors: ['#ef4444', '#991b1b', '#7f1d1d', '#450a0a', '#000000'],
      gravity: 1.5, scalar: 1.2, shapes: ['circle'],
    });
  }, []);

  const fireShieldEffect = useCallback(() => {
    confetti({
      particleCount: 60, spread: 80, origin: { y: 0.5 },
      colors: ['#06b6d4', '#22d3ee', '#67e8f9', '#a5f3fc', '#ffffff'],
      gravity: 0.8, scalar: 1, shapes: ['circle'],
    });
  }, []);

  useEffect(() => {
    const timer = setTimeout(() => {
      if (revealStep < totalSteps) {
        setRevealStep(prev => prev + 1);
        if (revealStep < kills.length) {
          const kill = kills[revealStep];
          if (kill.blocked) { fireShieldEffect(); playShieldSound(); }
          else { fireDeathEffect(); playKillSound(); }
        } else {
          playRevealSound();
        }
      } else {
        setShowResults(true);
      }
    }, revealStep === 0 ? 1500 : 2500);
    return () => clearTimeout(timer);
  }, [revealStep, totalSteps, kills, fireDeathEffect, fireShieldEffect]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-950 via-gray-900 to-gray-950 flex flex-col items-center justify-center p-4 relative overflow-hidden">
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute inset-0 bg-gradient-to-b from-orange-900/10 via-transparent to-transparent animate-pulse" />
      </div>

      <div className="relative z-10 w-full max-w-lg">
        <div className="text-center mb-8">
          <div className="text-5xl mb-3">☀️</div>
          <h2 className="text-3xl font-bold text-amber-300 mb-1">Dawn Breaks</h2>
          <p className="text-gray-400">Round {room.round} — What happened last night?</p>
        </div>

        {/* Reveal Cards */}
        <div className="space-y-4 mb-8">
          {kills.map((kill, index) => {
            if (index >= revealStep) return null;
            const player = room.players.find(p => p.id === kill.targetId);
            if (!player) return null;

            // Only show shield count to the target player themselves
            const isTargetMe = player.id === currentPlayerId;

            return (
              <div key={kill.targetId}
                className={`rounded-2xl p-4 border-2 transition-all duration-700 animate-fade-in ${
                  kill.blocked
                    ? 'bg-cyan-900/20 border-cyan-500/40 shadow-lg shadow-cyan-500/20'
                    : 'bg-red-900/20 border-red-500/40 shadow-lg shadow-red-500/20'
                }`}
              >
                <div className="flex items-center gap-4">
                  <div className="w-16 h-16 rounded-full bg-gray-800 flex items-center justify-center text-3xl overflow-hidden border-2 border-gray-600 shrink-0 relative">
                    {player.avatar?.startsWith('data:') ? (
                      <img src={player.avatar} alt="" className="w-full h-full object-cover" />
                    ) : (
                      <span>{player.avatar || '😎'}</span>
                    )}
                    {!kill.blocked && (
                      <div className="absolute inset-0 bg-red-900/60 flex items-center justify-center animate-fade-in">
                        <span className="text-3xl">💀</span>
                      </div>
                    )}
                    {kill.blocked && (
                      <div className="absolute inset-0 bg-cyan-500/30 flex items-center justify-center animate-pulse">
                        <span className="text-2xl">🛡️</span>
                      </div>
                    )}
                  </div>
                  <div className="flex-1">
                    <h3 className="text-white font-bold text-lg">{player.name} {player.id === currentPlayerId && <span className="text-indigo-400 text-xs">← You</span>}</h3>
                    {kill.blocked ? (
                      <div>
                        <p className="text-cyan-400 font-medium animate-pulse">✨ PROTECTED! Shield absorbed the attack!</p>
                        {/* Only you see your own shield count */}
                        {isTargetMe && (
                          <p className="text-cyan-300/60 text-xs mt-1">Your shields remaining: {player.shields}</p>
                        )}
                      </div>
                    ) : (
                      <div>
                        <p className="text-red-400 font-medium">💀 ELIMINATED by the impostor</p>
                        <p className="text-red-300/60 text-xs mt-1">Rest in peace...</p>
                      </div>
                    )}
                  </div>
                </div>

                {kill.blocked ? (
                  <div className="mt-3 flex items-center gap-2 justify-center">
                    {[...Array(5)].map((_, i) => (
                      <div key={i} className="w-2 h-2 rounded-full bg-cyan-400 animate-bounce" style={{ animationDelay: `${i * 0.15}s` }} />
                    ))}
                  </div>
                ) : (
                  <div className="mt-3 flex items-center gap-2 justify-center">
                    {[...Array(5)].map((_, i) => (
                      <div key={i} className="w-2 h-2 rounded-full bg-red-500 animate-pulse" style={{ animationDelay: `${i * 0.2}s`, animationDuration: '0.8s' }} />
                    ))}
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {/* Continue to Voting */}
        {showResults && (
          <div className="animate-fade-in">
            {/* Alive summary — no shield counts visible to others */}
            <div className="bg-gray-900/60 rounded-xl p-4 mb-4 border border-gray-700">
              <h4 className="text-gray-400 text-sm mb-3 text-center">Survivors</h4>
              <div className="flex flex-wrap justify-center gap-2">
                {room.players.filter(p => p.isAlive).map(p => (
                  <div key={p.id} className="flex items-center gap-1 bg-gray-800 px-2 py-1 rounded-lg">
                    <span className="text-sm">
                      {p.avatar?.startsWith('data:') ? '📷' : p.avatar}
                    </span>
                    <span className="text-gray-300 text-xs">{p.name}</span>
                    {/* Only YOU see YOUR shields */}
                    {p.id === currentPlayerId && p.shields > 0 && (
                      <span className="text-xs text-cyan-400">🛡️×{p.shields}</span>
                    )}
                  </div>
                ))}
              </div>
              <p className="text-gray-500 text-xs text-center mt-2">
                {room.players.filter(p => p.isAlive).length} alive / {room.players.length} total
              </p>
            </div>

            <button
              onClick={startVoting}
              className="w-full py-4 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 text-white font-bold rounded-xl transition-all hover:scale-[1.02] shadow-lg shadow-indigo-600/30 text-lg"
            >
              🗳️ Start Emergency Meeting
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
