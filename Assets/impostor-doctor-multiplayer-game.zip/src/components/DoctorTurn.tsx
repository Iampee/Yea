import { useState } from 'react';
import { useGameStore } from '../store';
import PlayerCard from './PlayerCard';
import ParticlesBackground from './ParticlesBackground';
import { playSelectSound, playConfirmSound } from '../sounds';

export default function DoctorTurn() {
  const { room, currentPlayerId, doctorShield, doctorDone } = useGameStore();
  const [selectedTargets, setSelectedTargets] = useState<string[]>([]);
  const [confirmed, setConfirmed] = useState(false);

  if (!room) return null;

  const currentPlayer = room.players.find(p => p.id === currentPlayerId);
  const isDoctor = currentPlayer?.role === 'doctor' && currentPlayer?.isAlive;
  const isDead = currentPlayer && !currentPlayer.isAlive;

  if (isDead) {
    return (
      <div className="min-h-screen bg-black flex flex-col items-center justify-center p-4">
        <div className="text-center">
          <div className="text-5xl mb-4 opacity-50">💀</div>
          <h2 className="text-2xl font-bold text-gray-700 mb-2">You are eliminated</h2>
          <p className="text-gray-800 text-sm">Watching from the shadows...</p>
          <p className="text-gray-800 text-xs mt-4">The doctor is giving shields</p>
        </div>
      </div>
    );
  }

  if (!isDoctor) {
    return (
      <div className="min-h-screen bg-black flex flex-col items-center justify-center p-4 relative overflow-hidden">
        <div className="absolute inset-0">
          {[...Array(20)].map((_, i) => (
            <div key={i} className="absolute rounded-full bg-cyan-500/5 animate-pulse"
              style={{ width: Math.random() * 4 + 1 + 'px', height: Math.random() * 4 + 1 + 'px', left: Math.random() * 100 + '%', top: Math.random() * 100 + '%', animationDuration: Math.random() * 4 + 2 + 's' }}
            />
          ))}
        </div>
        <div className="relative z-10 text-center">
          <div className="text-5xl mb-4">😴</div>
          <h2 className="text-2xl font-bold text-gray-600 mb-2">You are sleeping...</h2>
          <p className="text-gray-700 text-sm">The doctor is giving shields</p>
          <div className="mt-8 flex gap-1 justify-center">
            <div className="w-3 h-3 bg-cyan-900/50 rounded-full animate-bounce" style={{ animationDelay: '0s' }} />
            <div className="w-3 h-3 bg-cyan-900/50 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }} />
            <div className="w-3 h-3 bg-cyan-900/50 rounded-full animate-bounce" style={{ animationDelay: '0.4s' }} />
          </div>
        </div>
      </div>
    );
  }

  const alivePlayers = room.players.filter(p => p.isAlive);
  const hasAlreadyActed = room.shieldActions.some(s => s.doctorId === currentPlayerId);

  if (confirmed || hasAlreadyActed) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-black via-cyan-950/20 to-black flex flex-col items-center justify-center p-4 relative overflow-hidden">
        <ParticlesBackground variant="doctor" />
        <div className="relative z-10 text-center">
          <div className="text-5xl mb-4">🛡️</div>
          <h2 className="text-2xl font-bold text-cyan-400 mb-2">Shields Assigned</h2>
          <p className="text-gray-500">Waiting for other doctors...</p>
          <div className="mt-8 flex gap-1 justify-center">
            <div className="w-3 h-3 bg-cyan-500/50 rounded-full animate-bounce" style={{ animationDelay: '0s' }} />
            <div className="w-3 h-3 bg-cyan-500/50 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }} />
            <div className="w-3 h-3 bg-cyan-500/50 rounded-full animate-bounce" style={{ animationDelay: '0.4s' }} />
          </div>
        </div>
      </div>
    );
  }

  const handleToggleTarget = (playerId: string) => {
    setSelectedTargets(prev => {
      if (prev.includes(playerId)) return prev.filter(id => id !== playerId);
      if (prev.length >= 2) return [prev[1], playerId];
      return [...prev, playerId];
    });
  };

  const handleConfirm = () => {
    if (!currentPlayerId || selectedTargets.length === 0) return;
    playConfirmSound();
    doctorShield(currentPlayerId, selectedTargets);
    setConfirmed(true);
    setTimeout(() => doctorDone(currentPlayerId), 500);
  };

  const shieldsPerTarget = selectedTargets.length === 1 ? 2 : 1;

  return (
    <div className="min-h-screen bg-gradient-to-br from-black via-cyan-950/30 to-black flex flex-col items-center p-4 relative overflow-hidden">
      <ParticlesBackground variant="doctor" />
      
      {/* Shield glow effect */}
      <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-b from-cyan-500/50 to-transparent animate-pulse" />
      
      <div className="relative z-10 w-full max-w-lg mt-8">
        <div className="text-center mb-4">
          <div className="text-5xl mb-2 animate-pulse">🛡️</div>
          <h2 className="text-3xl font-bold text-cyan-400 mb-1">Your Turn, Doctor</h2>
          <p className="text-cyan-300/60 text-sm">Protect the innocent — choose 1 or 2 players</p>
        </div>

        <div className="bg-gray-900/60 border border-cyan-500/20 rounded-xl p-3 mb-4 text-center">
          <p className="text-gray-300 text-sm">
            You have <span className="text-cyan-400 font-bold">2 shields</span> to distribute
          </p>
          {selectedTargets.length > 0 && (
            <p className="text-cyan-300 text-xs mt-1">
              {selectedTargets.length === 1 ? (
                <>Giving <span className="font-bold">2 shields</span> to 1 player</>
              ) : (
                <>Giving <span className="font-bold">1 shield</span> each to 2 players</>
              )}
            </p>
          )}
        </div>

        <div className="flex flex-wrap justify-center gap-3 mb-6">
          {alivePlayers.map(player => (
            <div key={player.id} className="relative">
              <PlayerCard
                player={player}
                selected={selectedTargets.includes(player.id)}
                glowColor="cyan"
                showMyShields={player.id === currentPlayerId}
                onClick={() => { handleToggleTarget(player.id); playSelectSound(); }}
              />
              {selectedTargets.includes(player.id) && (
                <div className="absolute -top-1 -right-1 bg-cyan-500 text-white text-xs w-5 h-5 rounded-full flex items-center justify-center font-bold shadow-lg shadow-cyan-500/50">
                  +{shieldsPerTarget}
                </div>
              )}
            </div>
          ))}
        </div>

        <button
          onClick={handleConfirm}
          disabled={selectedTargets.length === 0}
          className="w-full py-4 bg-gradient-to-r from-cyan-700 to-cyan-600 hover:from-cyan-600 hover:to-cyan-500 disabled:from-gray-700 disabled:to-gray-700 text-white font-bold rounded-xl transition-all hover:scale-[1.02] shadow-lg shadow-cyan-700/40 disabled:shadow-none text-lg disabled:text-gray-500"
        >
          {selectedTargets.length > 0 ? `Give Shields (${shieldsPerTarget}x${selectedTargets.length})` : 'Select player(s) to shield'}
        </button>
      </div>
    </div>
  );
}
