import { useState, useEffect } from 'react';
import { useGameStore } from '../store';
import confetti from 'canvas-confetti';
import { playKillSound, playRevealSound } from '../sounds';

export default function VoteResultPhase() {
  const { room, currentPlayerId, nextRound } = useGameStore();
  const [step, setStep] = useState(0); // 0=showing votes, 1=showing result, 2=done

  if (!room) return null;

  const latestResult = room.voteResults[room.voteResults.length - 1];
  if (!latestResult) return null;

  const alivePlayers = room.players.filter(p => p.isAlive || p.id === latestResult.ejectedId);

  // Build tally for display
  const tally: { playerId: string; name: string; avatar: string; voters: string[]; count: number }[] = [];
  const skipVoters: string[] = [];

  const voteMap = new Map<string, string[]>();
  latestResult.votes.forEach(v => {
    const voterName = room.players.find(p => p.id === v.voterId)?.name || '?';
    if (v.targetId === 'skip') {
      skipVoters.push(voterName);
    } else {
      const arr = voteMap.get(v.targetId) || [];
      arr.push(voterName);
      voteMap.set(v.targetId, arr);
    }
  });

  alivePlayers.forEach(p => {
    const voters = voteMap.get(p.id) || [];
    if (voters.length > 0) {
      tally.push({ playerId: p.id, name: p.name, avatar: p.avatar, voters, count: voters.length });
    }
  });
  tally.sort((a, b) => b.count - a.count);

  useEffect(() => {
    const t1 = setTimeout(() => setStep(1), 2000);
    const t2 = setTimeout(() => {
      setStep(2);
      if (latestResult.ejectedId) {
        playKillSound();
        confetti({
          particleCount: 60, spread: 80, origin: { y: 0.6 },
          colors: ['#ef4444', '#991b1b', '#7f1d1d', '#000'],
          gravity: 1.5, scalar: 1.2, shapes: ['circle'],
        });
      } else {
        playRevealSound();
      }
    }, 4000);
    return () => { clearTimeout(t1); clearTimeout(t2); };
  }, [latestResult.ejectedId]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-950 via-gray-900 to-gray-950 flex flex-col items-center justify-center p-4 relative overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,rgba(99,102,241,0.05),transparent_70%)]" />
      </div>

      <div className="relative z-10 w-full max-w-lg">
        {/* Header */}
        <div className="text-center mb-6">
          <div className="text-5xl mb-3">🗳️</div>
          <h2 className="text-3xl font-bold text-white mb-1">Vote Results</h2>
          <p className="text-gray-500 text-sm">Round {room.round}</p>
        </div>

        {/* Vote Tally */}
        <div className="space-y-2 mb-4">
          {tally.map((entry, i) => (
            <div key={entry.playerId} className={`bg-gray-900/60 border rounded-xl p-3 transition-all duration-500 ${
              step >= 1 && i === 0 && !latestResult.isTie && entry.playerId === latestResult.ejectedId
                ? 'border-red-500/50 bg-red-900/20 shadow-lg shadow-red-500/10'
                : 'border-gray-700/50'
            } ${step >= 0 ? 'animate-fade-in' : 'opacity-0'}`} style={{ animationDelay: `${i * 200}ms` }}>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-gray-800 flex items-center justify-center text-xl overflow-hidden border-2 border-gray-600 shrink-0">
                  {entry.avatar?.startsWith('data:') ? (
                    <img src={entry.avatar} alt="" className="w-full h-full object-cover" />
                  ) : (
                    <span className="text-sm">{entry.avatar}</span>
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <span className="text-white font-medium text-sm truncate">{entry.name}</span>
                    {entry.playerId === currentPlayerId && <span className="text-indigo-400 text-xs">← You</span>}
                  </div>
                  <div className="text-gray-500 text-xs mt-0.5 truncate">
                    Voted by: {entry.voters.join(', ')}
                  </div>
                </div>
                {/* Vote bar */}
                <div className="flex items-center gap-1.5">
                  <div className="w-24 h-3 bg-gray-800 rounded-full overflow-hidden">
                    <div
                      className={`h-full rounded-full transition-all duration-1000 ${
                        entry.playerId === latestResult.ejectedId ? 'bg-red-500' : 'bg-amber-500/60'
                      }`}
                      style={{ width: `${(entry.count / latestResult.votes.length) * 100}%` }}
                    />
                  </div>
                  <span className="text-amber-400 text-sm font-bold w-5 text-right">{entry.count}</span>
                </div>
              </div>
            </div>
          ))}

          {/* Skip votes */}
          {skipVoters.length > 0 && (
            <div className="bg-gray-900/40 border border-gray-700/30 rounded-xl p-3 animate-fade-in" style={{ animationDelay: `${tally.length * 200}ms` }}>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-gray-700 flex items-center justify-center text-xl">⏭️</div>
                <div className="flex-1 min-w-0">
                  <span className="text-gray-400 font-medium text-sm">Skip Vote</span>
                  <div className="text-gray-600 text-xs mt-0.5 truncate">
                    {skipVoters.join(', ')}
                  </div>
                </div>
                <div className="flex items-center gap-1.5">
                  <div className="w-24 h-3 bg-gray-800 rounded-full overflow-hidden">
                    <div className="h-full rounded-full bg-gray-500/50 transition-all duration-1000"
                      style={{ width: `${(skipVoters.length / latestResult.votes.length) * 100}%` }}
                    />
                  </div>
                  <span className="text-gray-400 text-sm font-bold w-5 text-right">{skipVoters.length}</span>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Ejection Result */}
        {step >= 2 && (
          <div className="animate-fade-in mb-6">
            {latestResult.ejectedId ? (
              <div className={`rounded-2xl p-5 border-2 text-center ${
                latestResult.wasImpostor
                  ? 'bg-green-900/20 border-green-500/40 shadow-lg shadow-green-500/10'
                  : 'bg-red-900/20 border-red-500/40 shadow-lg shadow-red-500/10'
              }`}>
                {/* Ejected player */}
                <div className="mb-3">
                  <div className="w-20 h-20 mx-auto rounded-full bg-gray-800 flex items-center justify-center text-4xl overflow-hidden border-3 border-gray-600 relative">
                    {(() => {
                      const ejected = room.players.find(p => p.id === latestResult.ejectedId);
                      if (!ejected) return null;
                      return ejected.avatar?.startsWith('data:') ? (
                        <img src={ejected.avatar} alt="" className="w-full h-full object-cover" />
                      ) : (
                        <span>{ejected.avatar}</span>
                      );
                    })()}
                    <div className="absolute inset-0 bg-black/40 flex items-center justify-center">
                      <span className="text-3xl">🚀</span>
                    </div>
                  </div>
                </div>

                <h3 className="text-white font-bold text-xl mb-1">
                  {latestResult.ejectedName} was ejected.
                </h3>
                <p className={`font-bold text-lg ${latestResult.wasImpostor ? 'text-green-400' : 'text-red-400'}`}>
                  {latestResult.wasImpostor
                    ? '✅ They were the Impostor!'
                    : '❌ They were NOT the Impostor.'
                  }
                </p>
                <p className="text-gray-500 text-xs mt-2">
                  {room.players.filter(p => p.isAlive && p.role === 'impostor').length} impostor(s) remaining
                </p>
              </div>
            ) : (
              <div className="rounded-2xl p-5 border-2 bg-gray-800/30 border-gray-600/40 text-center">
                <div className="text-5xl mb-3">🤷</div>
                <h3 className="text-white font-bold text-xl mb-1">
                  {latestResult.isTie ? 'It was a tie!' : 'No one was ejected.'}
                </h3>
                <p className="text-gray-500 text-sm">
                  {latestResult.isTie ? 'The votes were tied — no one was ejected.' : 'The village chose to skip.'}
                </p>
              </div>
            )}
          </div>
        )}

        {/* Continue button */}
        {step >= 2 && (
          <div className="animate-fade-in">
            <button
              onClick={nextRound}
              className="w-full py-4 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 text-white font-bold rounded-xl transition-all hover:scale-[1.02] shadow-lg shadow-indigo-600/30 text-lg"
            >
              Continue to Next Night →
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
