import { useState, useRef, useEffect } from 'react';
import { useGameStore } from '../store';
import ParticlesBackground from './ParticlesBackground';
import { playSelectSound, playConfirmSound } from '../sounds';

export default function VotingPhase() {
  const { room, currentPlayerId, castVote, sendChat } = useGameStore();
  const [selectedTarget, setSelectedTarget] = useState<string | 'skip' | null>(null);
  const [confirmed, setConfirmed] = useState(false);
  const [chatInput, setChatInput] = useState('');
  const chatEndRef = useRef<HTMLDivElement>(null);
  const chatContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [room?.chatMessages.length]);

  if (!room) return null;

  const currentPlayer = room.players.find(p => p.id === currentPlayerId);
  const isDead = currentPlayer && !currentPlayer.isAlive;
  const hasVoted = room.votes.some(v => v.voterId === currentPlayerId);
  const alivePlayers = room.players.filter(p => p.isAlive);

  // Calculate vote tallies for display (only show after you've voted)
  const voteTally: Map<string, string[]> = new Map();
  let skipVoters: string[] = [];
  if (hasVoted || confirmed) {
    room.votes.forEach(v => {
      const voterName = room.players.find(p => p.id === v.voterId)?.name || '?';
      if (v.targetId === 'skip') {
        skipVoters.push(voterName);
      } else {
        const existing = voteTally.get(v.targetId) || [];
        existing.push(voterName);
        voteTally.set(v.targetId, existing);
      }
    });
  }

  const totalVoted = room.votes.length;
  const totalAlive = alivePlayers.length;

  // Timer display
  const minutes = Math.floor(room.votingTimeLeft / 60);
  const seconds = room.votingTimeLeft % 60;
  const timerColor = room.votingTimeLeft <= 10 ? 'text-red-400' : room.votingTimeLeft <= 30 ? 'text-amber-400' : 'text-white';

  const handleConfirmVote = () => {
    if (!selectedTarget || !currentPlayerId) return;
    playConfirmSound();
    castVote(currentPlayerId, selectedTarget);
    setConfirmed(true);
  };

  const handleSendChat = () => {
    if (!chatInput.trim()) return;
    sendChat(chatInput);
    setChatInput('');
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendChat();
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-950 via-indigo-950/30 to-gray-950 flex flex-col relative overflow-hidden">
      <ParticlesBackground variant="voting" />

      <div className="relative z-10 flex flex-col h-[calc(100vh-2.75rem)] w-full max-w-lg mx-auto">
        {/* Header */}
        <div className="shrink-0 px-4 pt-3 pb-2">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-2">
              <span className="text-2xl">🗳️</span>
              <div>
                <h2 className="text-lg font-bold text-white leading-tight">Emergency Meeting</h2>
                <p className="text-gray-500 text-xs">Who is the impostor? Discuss and vote!</p>
              </div>
            </div>
            <div className={`text-right ${timerColor}`}>
              <div className="text-2xl font-mono font-bold tabular-nums">
                {minutes}:{seconds.toString().padStart(2, '0')}
              </div>
              <div className="text-gray-500 text-xs">{totalVoted}/{totalAlive} voted</div>
            </div>
          </div>

          {/* Progress bar */}
          <div className="w-full h-1.5 bg-gray-800 rounded-full overflow-hidden">
            <div
              className={`h-full rounded-full transition-all duration-1000 ${room.votingTimeLeft <= 10 ? 'bg-red-500' : room.votingTimeLeft <= 30 ? 'bg-amber-500' : 'bg-indigo-500'}`}
              style={{ width: `${(room.votingTimeLeft / 60) * 100}%` }}
            />
          </div>
        </div>

        {/* Voting Panel — Among Us style grid */}
        <div className="shrink-0 px-3 py-2">
          <div className="bg-gray-900/70 backdrop-blur-sm rounded-xl border border-gray-700/50 p-3">
            <div className="grid grid-cols-3 sm:grid-cols-4 gap-1.5">
              {alivePlayers.map(player => {
                const isMe = player.id === currentPlayerId;
                const votes = voteTally.get(player.id) || [];
                const isSelected = selectedTarget === player.id;
                const voterHasVoted = room.votes.some(v => v.voterId === player.id);

                return (
                  <button
                    key={player.id}
                    onClick={() => {
                      if (hasVoted || isDead) return;
                      setSelectedTarget(player.id);
                      playSelectSound();
                    }}
                    disabled={hasVoted || !!isDead}
                    className={`relative flex flex-col items-center gap-0.5 p-1.5 rounded-lg transition-all duration-200 ${
                      isSelected ? 'bg-amber-600/30 ring-2 ring-amber-500 scale-105' :
                      'bg-gray-800/50 hover:bg-gray-700/50'
                    } ${(hasVoted || isDead) ? 'cursor-default' : 'cursor-pointer active:scale-95'}`}
                  >
                    {/* Avatar */}
                    <div className={`w-11 h-11 rounded-full bg-gray-800 flex items-center justify-center text-lg overflow-hidden border-2 transition-all ${
                      isSelected ? 'border-amber-500 shadow-md shadow-amber-500/40' :
                      isMe ? 'border-indigo-500' : 'border-gray-600'
                    }`}>
                      {player.avatar?.startsWith('data:') ? (
                        <img src={player.avatar} alt="" className="w-full h-full object-cover" />
                      ) : (
                        <span className="text-base">{player.avatar || '😎'}</span>
                      )}
                    </div>
                    {/* Name */}
                    <span className={`text-[10px] font-medium truncate w-full text-center ${isMe ? 'text-indigo-300' : 'text-gray-300'}`}>
                      {isMe ? 'You' : player.name}
                    </span>

                    {/* Vote count (visible after you vote) */}
                    {(hasVoted || confirmed) && votes.length > 0 && (
                      <div className="absolute -top-1 -right-1 bg-amber-500 text-black text-[10px] w-5 h-5 rounded-full flex items-center justify-center font-bold shadow animate-fade-in">
                        {votes.length}
                      </div>
                    )}

                    {/* Voted indicator */}
                    {voterHasVoted && (
                      <div className="absolute top-0 left-0 w-4 h-4 bg-green-600 rounded-full flex items-center justify-center shadow">
                        <span className="text-white text-[8px]">✓</span>
                      </div>
                    )}
                  </button>
                );
              })}

              {/* Skip Vote */}
              <button
                onClick={() => {
                  if (hasVoted || isDead) return;
                  setSelectedTarget('skip');
                  playSelectSound();
                }}
                disabled={hasVoted || !!isDead}
                className={`relative flex flex-col items-center gap-0.5 p-1.5 rounded-lg transition-all duration-200 ${
                  selectedTarget === 'skip' ? 'bg-gray-600/40 ring-2 ring-gray-400 scale-105' :
                  'bg-gray-800/30 hover:bg-gray-700/40 border border-dashed border-gray-600'
                } ${(hasVoted || isDead) ? 'cursor-default' : 'cursor-pointer active:scale-95'}`}
              >
                <div className={`w-11 h-11 rounded-full bg-gray-700 flex items-center justify-center text-lg border-2 ${
                  selectedTarget === 'skip' ? 'border-gray-400' : 'border-gray-600'
                }`}>
                  ⏭️
                </div>
                <span className="text-[10px] font-medium text-gray-400">Skip</span>
                {(hasVoted || confirmed) && skipVoters.length > 0 && (
                  <div className="absolute -top-1 -right-1 bg-gray-500 text-white text-[10px] w-5 h-5 rounded-full flex items-center justify-center font-bold shadow animate-fade-in">
                    {skipVoters.length}
                  </div>
                )}
              </button>
            </div>

            {/* Confirm button */}
            {!hasVoted && !isDead && (
              <button
                onClick={handleConfirmVote}
                disabled={!selectedTarget}
                className="w-full mt-2 py-2.5 bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-500 hover:to-orange-500 disabled:from-gray-700 disabled:to-gray-700 text-white font-bold rounded-lg transition-all text-sm disabled:text-gray-500"
              >
                {selectedTarget
                  ? selectedTarget === 'skip'
                    ? 'Confirm Skip Vote'
                    : `Vote to eject ${alivePlayers.find(p => p.id === selectedTarget)?.name}`
                  : 'Select someone to vote'}
              </button>
            )}

            {(hasVoted || isDead) && (
              <div className="w-full mt-2 py-2 text-center text-sm">
                {isDead ? (
                  <span className="text-gray-600">💀 You are dead — spectating</span>
                ) : (
                  <span className="text-green-400/70">✓ Vote cast! Waiting for others...</span>
                )}
              </div>
            )}
          </div>
        </div>

        {/* Chat Area */}
        <div className="flex-1 flex flex-col min-h-0 px-3 pb-2">
          <div className="flex items-center gap-2 mb-1.5">
            <span className="text-gray-400 text-xs font-medium">💬 Discussion</span>
            <span className="text-gray-600 text-xs">({room.chatMessages.length} messages)</span>
          </div>

          {/* Messages */}
          <div ref={chatContainerRef} className="flex-1 overflow-y-auto bg-gray-900/50 rounded-xl border border-gray-800/50 p-2 space-y-1.5 min-h-0 mb-2">
            {room.chatMessages.length === 0 && (
              <div className="text-center text-gray-700 text-xs py-8">
                No messages yet. Start discussing!
              </div>
            )}
            {room.chatMessages.map(msg => {
              const isMe = msg.playerId === currentPlayerId;
              return (
                <div key={msg.id} className={`flex gap-2 animate-fade-in ${isMe ? 'flex-row-reverse' : ''}`}>
                  <div className="w-7 h-7 rounded-full bg-gray-800 flex items-center justify-center text-sm overflow-hidden border border-gray-700 shrink-0">
                    {msg.playerAvatar?.startsWith('data:') ? (
                      <img src={msg.playerAvatar} alt="" className="w-full h-full object-cover" />
                    ) : (
                      <span className="text-xs">{msg.playerAvatar}</span>
                    )}
                  </div>
                  <div className={`max-w-[75%] ${isMe ? 'text-right' : ''}`}>
                    <span className={`text-[10px] font-medium ${isMe ? 'text-indigo-400' : 'text-gray-500'}`}>
                      {isMe ? 'You' : msg.playerName}
                    </span>
                    <div className={`px-2.5 py-1.5 rounded-xl text-sm leading-snug ${
                      isMe
                        ? 'bg-indigo-600/40 text-indigo-100 rounded-tr-sm'
                        : 'bg-gray-800/80 text-gray-200 rounded-tl-sm'
                    }`}>
                      {msg.text}
                    </div>
                  </div>
                </div>
              );
            })}
            <div ref={chatEndRef} />
          </div>

          {/* Chat input */}
          {currentPlayer?.isAlive ? (
            <div className="flex gap-2 shrink-0">
              <input
                type="text"
                value={chatInput}
                onChange={e => setChatInput(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder="Type a message..."
                maxLength={200}
                className="flex-1 bg-gray-800 border border-gray-700 focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500/50 text-white text-sm px-3 py-2 rounded-xl outline-none transition-all"
              />
              <button
                onClick={handleSendChat}
                disabled={!chatInput.trim()}
                className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 disabled:bg-gray-700 text-white rounded-xl text-sm font-medium transition-all disabled:text-gray-500"
              >
                Send
              </button>
            </div>
          ) : (
            <div className="text-center text-gray-700 text-xs py-1 shrink-0">
              Dead players cannot chat
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
