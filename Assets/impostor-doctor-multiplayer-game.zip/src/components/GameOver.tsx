import { useEffect, useCallback } from 'react';
import { useGameStore } from '../store';
import confetti from 'canvas-confetti';
import ParticlesBackground from './ParticlesBackground';
import { playVictorySound, playDefeatSound } from '../sounds';

export default function GameOver() {
  const { room, currentPlayerId, resetGame, backToLobby } = useGameStore();

  if (!room) return null;

  const currentPlayer = room.players.find(p => p.id === currentPlayerId);
  const isWinner = room.winner === 'impostor'
    ? currentPlayer?.role === 'impostor'
    : currentPlayer?.role !== 'impostor';

  const impostors = room.players.filter(p => p.role === 'impostor');
  const doctors = room.players.filter(p => p.role === 'doctor');
  const innocents = room.players.filter(p => p.role === 'innocent');

  const fireVictoryConfetti = useCallback(() => {
    const duration = 3000;
    const end = Date.now() + duration;
    const frame = () => {
      confetti({
        particleCount: 5, angle: 60, spread: 55, origin: { x: 0 },
        colors: room?.winner === 'impostor'
          ? ['#ef4444', '#dc2626', '#f97316', '#991b1b']
          : ['#06b6d4', '#22d3ee', '#10b981', '#3b82f6'],
      });
      confetti({
        particleCount: 5, angle: 120, spread: 55, origin: { x: 1 },
        colors: room?.winner === 'impostor'
          ? ['#ef4444', '#dc2626', '#f97316', '#991b1b']
          : ['#06b6d4', '#22d3ee', '#10b981', '#3b82f6'],
      });
      if (Date.now() < end) requestAnimationFrame(frame);
    };
    frame();
  }, [room?.winner]);

  useEffect(() => {
    const timer = setTimeout(() => {
      fireVictoryConfetti();
      if (isWinner) playVictorySound();
      else playDefeatSound();
    }, 500);
    return () => clearTimeout(timer);
  }, [fireVictoryConfetti, isWinner]);

  const totalKills = room.roundResults.reduce((s, r) => s + r.kills.filter(k => !k.blocked).length, 0);
  const totalSaves = room.roundResults.reduce((s, r) => s + r.kills.filter(k => k.blocked).length, 0);
  const totalEjections = room.voteResults.filter(v => v.ejectedId !== null).length;

  return (
    <div className={`min-h-screen flex flex-col items-center justify-center p-4 relative overflow-hidden ${
      room.winner === 'impostor'
        ? 'bg-gradient-to-br from-gray-950 via-red-950/50 to-gray-950'
        : 'bg-gradient-to-br from-gray-950 via-cyan-950/50 to-gray-950'
    }`}>
      <ParticlesBackground variant={room.winner === 'impostor' ? 'victory-red' : 'victory-cyan'} />

      <div className="relative z-10 w-full max-w-lg text-center overflow-y-auto max-h-screen pb-8 pt-4">
        <div className="mb-8">
          <div className="text-7xl mb-4 animate-bounce">{room.winner === 'impostor' ? '🔪' : '🛡️'}</div>
          <h1 className={`text-4xl md:text-5xl font-black mb-2 ${room.winner === 'impostor' ? 'text-red-400' : 'text-cyan-400'}`}>
            {room.winner === 'impostor' ? 'IMPOSTORS WIN!' : 'INNOCENTS WIN!'}
          </h1>
          <p className={`text-lg ${room.winner === 'impostor' ? 'text-red-300/60' : 'text-cyan-300/60'}`}>
            {room.winner === 'impostor' ? 'The shadows have consumed the village...' : 'The light prevails! The impostor has been stopped!'}
          </p>
          <div className={`mt-4 inline-block px-6 py-2 rounded-full text-lg font-bold ${
            isWinner ? 'bg-green-600/20 text-green-400 border border-green-500/30' : 'bg-red-600/20 text-red-400 border border-red-500/30'
          }`}>
            {isWinner ? '🎉 You Won!' : '😞 You Lost'}
          </div>
        </div>

        {/* Role Reveals */}
        <div className="space-y-4 mb-8">
          <div className="bg-red-900/20 border border-red-500/30 rounded-xl p-4">
            <h3 className="text-red-400 font-bold mb-3 text-sm">🔪 IMPOSTORS</h3>
            <div className="flex flex-wrap justify-center gap-3">
              {impostors.map(p => (
                <div key={p.id} className="flex flex-col items-center gap-1">
                  <div className={`w-14 h-14 rounded-full bg-gray-800 flex items-center justify-center text-2xl overflow-hidden border-2 ${p.isAlive ? 'border-red-500' : 'border-gray-600 opacity-50'}`}>
                    {p.avatar?.startsWith('data:') ? <img src={p.avatar} alt="" className="w-full h-full object-cover" /> : <span>{p.avatar}</span>}
                  </div>
                  <span className="text-white text-xs font-medium">{p.name}</span>
                  {!p.isAlive && <span className="text-red-400 text-xs">💀</span>}
                </div>
              ))}
            </div>
          </div>
          <div className="bg-cyan-900/20 border border-cyan-500/30 rounded-xl p-4">
            <h3 className="text-cyan-400 font-bold mb-3 text-sm">🛡️ DOCTORS</h3>
            <div className="flex flex-wrap justify-center gap-3">
              {doctors.map(p => (
                <div key={p.id} className="flex flex-col items-center gap-1">
                  <div className={`w-14 h-14 rounded-full bg-gray-800 flex items-center justify-center text-2xl overflow-hidden border-2 ${p.isAlive ? 'border-cyan-500' : 'border-gray-600 opacity-50'}`}>
                    {p.avatar?.startsWith('data:') ? <img src={p.avatar} alt="" className="w-full h-full object-cover" /> : <span>{p.avatar}</span>}
                  </div>
                  <span className="text-white text-xs font-medium">{p.name}</span>
                  {!p.isAlive && <span className="text-red-400 text-xs">💀</span>}
                </div>
              ))}
            </div>
          </div>
          <div className="bg-gray-800/40 border border-gray-600/30 rounded-xl p-4">
            <h3 className="text-gray-400 font-bold mb-3 text-sm">👤 INNOCENTS</h3>
            <div className="flex flex-wrap justify-center gap-3">
              {innocents.map(p => (
                <div key={p.id} className="flex flex-col items-center gap-1">
                  <div className={`w-14 h-14 rounded-full bg-gray-800 flex items-center justify-center text-2xl overflow-hidden border-2 ${p.isAlive ? 'border-gray-500' : 'border-gray-700 opacity-50'}`}>
                    {p.avatar?.startsWith('data:') ? <img src={p.avatar} alt="" className="w-full h-full object-cover" /> : <span>{p.avatar}</span>}
                  </div>
                  <span className="text-white text-xs font-medium">{p.name}</span>
                  {!p.isAlive && <span className="text-red-400 text-xs">💀</span>}
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Stats */}
        <div className="bg-gray-900/60 rounded-xl p-4 mb-6 border border-gray-700">
          <h4 className="text-gray-400 text-sm mb-2 font-medium">Game Stats</h4>
          <div className="flex justify-around text-center">
            <div><div className="text-2xl font-bold text-white">{room.round}</div><div className="text-gray-500 text-xs">Rounds</div></div>
            <div><div className="text-2xl font-bold text-red-400">{totalKills}</div><div className="text-gray-500 text-xs">Kills</div></div>
            <div><div className="text-2xl font-bold text-cyan-400">{totalSaves}</div><div className="text-gray-500 text-xs">Saves</div></div>
            <div><div className="text-2xl font-bold text-amber-400">{totalEjections}</div><div className="text-gray-500 text-xs">Ejected</div></div>
          </div>
        </div>

        <div className="space-y-3">
          <button onClick={resetGame} className="w-full py-4 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-500 hover:to-pink-500 text-white font-bold rounded-xl transition-all hover:scale-[1.02] shadow-lg shadow-purple-600/30 text-lg">
            🔄 Play Again
          </button>
          <button onClick={backToLobby} className="w-full py-3 bg-gray-800 hover:bg-gray-700 text-gray-300 font-medium rounded-xl transition-all border border-gray-600">
            🏠 Back to Home
          </button>
        </div>
      </div>
    </div>
  );
}
