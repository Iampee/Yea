import { useState } from 'react';
import { useGameStore } from '../store';
import PlayerCard from './PlayerCard';
import ParticlesBackground from './ParticlesBackground';
import { playSelectSound, playConfirmSound } from '../sounds';

export default function ImpostorTurn() {
  const { room, currentPlayerId, impostorKill, impostorDone } = useGameStore();
  const [selectedTarget, setSelectedTarget] = useState<string | null>(null);
  const [confirmed, setConfirmed] = useState(false);

  if (!room) return null;

  const currentPlayer = room.players.find(p => p.id === currentPlayerId);
  const isImpostor = currentPlayer?.role === 'impostor' && currentPlayer?.isAlive;
  const isDead = currentPlayer && !currentPlayer.isAlive;

  if (isDead) {
    return (
      <div className="min-h-screen bg-black flex flex-col items-center justify-center p-4 relative overflow-hidden">
        <div className="text-center">
          <div className="text-5xl mb-4 opacity-50">💀</div>
          <h2 className="text-2xl font-bold text-gray-700 mb-2">You are eliminated</h2>
          <p className="text-gray-800 text-sm">Watching from the shadows...</p>
          <p className="text-gray-800 text-xs mt-4">The impostor is choosing a victim</p>
        </div>
      </div>
    );
  }

  if (!isImpostor) {
    return (
      <div className="min-h-screen bg-black flex flex-col items-center justify-center p-4 relative overflow-hidden">
        <div className="absolute inset-0">
          {[...Array(20)].map((_, i) => (
            <div key={i} className="absolute rounded-full bg-red-500/5 animate-pulse"
              style={{ width: Math.random() * 4 + 1 + 'px', height: Math.random() * 4 + 1 + 'px', left: Math.random() * 100 + '%', top: Math.random() * 100 + '%', animationDuration: Math.random() * 4 + 2 + 's' }}
            />
          ))}
        </div>
        <div className="relative z-10 text-center">
          <div className="text-5xl mb-4">😴</div>
          <h2 className="text-2xl font-bold text-gray-600 mb-2">You are sleeping...</h2>
          <p className="text-gray-700 text-sm">The impostor is choosing a victim</p>
          <div className="mt-8 flex gap-1 justify-center">
            <div className="w-3 h-3 bg-red-900/50 rounded-full animate-bounce" style={{ animationDelay: '0s' }} />
            <div className="w-3 h-3 bg-red-900/50 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }} />
            <div className="w-3 h-3 bg-red-900/50 rounded-full animate-bounce" style={{ animationDelay: '0.4s' }} />
          </div>
        </div>
      </div>
    );
  }

  const targets = room.players.filter(p => p.isAlive && p.role !== 'impostor');
  const hasAlreadyPicked = room.killAttempts.some(k => k.impostorId === currentPlayerId);

  if (confirmed || hasAlreadyPicked) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-black via-red-950/20 to-black flex flex-col items-center justify-center p-4 relative overflow-hidden">
        <ParticlesBackground variant="impostor" />
        <div className="relative z-10 text-center">
          <div className="text-5xl mb-4">🔪</div>
          <h2 className="text-2xl font-bold text-red-400 mb-2">Target Selected</h2>
          <p className="text-gray-500">Waiting for other impostors...</p>
          <div className="mt-8 flex gap-1 justify-center">
            <div className="w-3 h-3 bg-red-500/50 rounded-full animate-bounce" style={{ animationDelay: '0s' }} />
            <div className="w-3 h-3 bg-red-500/50 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }} />
            <div className="w-3 h-3 bg-red-500/50 rounded-full animate-bounce" style={{ animationDelay: '0.4s' }} />
          </div>
        </div>
      </div>
    );
  }

  const handleConfirm = () => {
    if (!selectedTarget || !currentPlayerId) return;
    playConfirmSound();
    impostorKill(currentPlayerId, selectedTarget);
    setConfirmed(true);
    setTimeout(() => impostorDone(currentPlayerId), 500);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-black via-red-950/30 to-black flex flex-col items-center p-4 relative overflow-hidden">
      <ParticlesBackground variant="impostor" />
      
      {/* Blood-like drip effect */}
      <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-b from-red-600 to-transparent animate-pulse" />

      <div className="relative z-10 w-full max-w-lg mt-8">
        <div className="text-center mb-6">
          <div className="text-5xl mb-2 animate-pulse">🔪</div>
          <h2 className="text-3xl font-bold text-red-400 mb-1">Your Turn, Impostor</h2>
          <p className="text-red-300/60 text-sm">Choose a player to eliminate</p>
        </div>

        <div className="flex flex-wrap justify-center gap-3 mb-8">
          {targets.map(player => (
            <PlayerCard
              key={player.id}
              player={player}
              selected={selectedTarget === player.id}
              glowColor="red"
              onClick={() => { setSelectedTarget(player.id); playSelectSound(); }}
            />
          ))}
        </div>

        <button
          onClick={handleConfirm}
          disabled={!selectedTarget}
          className="w-full py-4 bg-gradient-to-r from-red-700 to-red-600 hover:from-red-600 hover:to-red-500 disabled:from-gray-700 disabled:to-gray-700 text-white font-bold rounded-xl transition-all hover:scale-[1.02] shadow-lg shadow-red-700/40 disabled:shadow-none text-lg disabled:text-gray-500"
        >
          {selectedTarget ? `Kill ${targets.find(t => t.id === selectedTarget)?.name}` : 'Select a target'}
        </button>
      </div>
    </div>
  );
}
