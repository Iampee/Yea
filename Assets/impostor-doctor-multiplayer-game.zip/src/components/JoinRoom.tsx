import { useState } from 'react';
import { useGameStore } from '../store';
import ParticlesBackground from './ParticlesBackground';

export default function JoinRoom() {
  const { joinRoom, setScreen, isConnecting, connectionError } = useGameStore();
  const [code, setCode] = useState('');
  const [localError, setLocalError] = useState('');

  const handleJoin = async () => {
    if (code.length < 4) {
      setLocalError('Room code must be at least 4 characters');
      return;
    }
    setLocalError('');
    const success = await joinRoom(code);
    if (!success && !connectionError) {
      setLocalError('Failed to join room');
    }
  };

  const displayError = localError || connectionError;

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-950 via-blue-950/30 to-gray-950 flex flex-col items-center justify-center p-4 relative overflow-hidden">
      <ParticlesBackground variant="doctor" />
      <div className="relative z-10 bg-gray-900/80 backdrop-blur-xl border border-cyan-500/30 rounded-2xl p-6 w-full max-w-md shadow-2xl shadow-cyan-900/20">
        <button
          onClick={() => setScreen('home')}
          className="text-gray-400 hover:text-white mb-4 flex items-center gap-1 transition-colors"
          disabled={isConnecting}
        >
          ← Back
        </button>

        <h2 className="text-3xl font-bold text-white text-center mb-6">
          🚪 Join Room
        </h2>

        {displayError && (
          <div className="bg-red-900/30 border border-red-500/50 text-red-300 px-4 py-2 rounded-lg mb-4 text-sm">
            {displayError}
          </div>
        )}

        <div className="mb-6">
          <label className="text-gray-400 text-sm mb-2 block">Room Code</label>
          <input
            type="text"
            value={code}
            onChange={(e) => {
              setCode(e.target.value.toUpperCase());
              setLocalError('');
            }}
            placeholder="ENTER CODE"
            maxLength={6}
            className="w-full bg-gray-800 border border-gray-600 focus:border-cyan-500 focus:ring-2 focus:ring-cyan-500/50 text-white px-4 py-4 rounded-xl outline-none transition-all text-2xl text-center tracking-[0.3em] font-mono uppercase"
            disabled={isConnecting}
          />
          <p className="text-gray-500 text-xs mt-2 text-center">
            Ask the host for the 6-character room code
          </p>
        </div>

        <button
          onClick={handleJoin}
          disabled={!code.trim() || isConnecting}
          className="w-full py-4 bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 disabled:from-gray-600 disabled:to-gray-600 text-white font-bold rounded-xl transition-all hover:scale-[1.02] shadow-lg shadow-cyan-600/30 disabled:shadow-none text-lg flex items-center justify-center gap-2"
        >
          {isConnecting ? (
            <>
              <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
              Joining...
            </>
          ) : (
            'Join Room 🎮'
          )}
        </button>
      </div>
    </div>
  );
}
