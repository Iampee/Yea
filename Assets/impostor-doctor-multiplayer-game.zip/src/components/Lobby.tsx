import { useGameStore } from '../store';
import ParticlesBackground from './ParticlesBackground';
import { network } from '../network';

const difficultyLabels: Record<number, string> = { 1: 'Easy', 2: 'Normal', 3: 'Hard', 4: 'Expert', 5: '💀' };
const difficultyColors: Record<number, string> = { 1: 'text-green-400', 2: 'text-yellow-400', 3: 'text-orange-400', 4: 'text-red-400', 5: 'text-purple-400' };

export default function Lobby() {
  const { room, currentPlayerId, addBot, removeBot, startGame, backToLobby, botDifficulty, setBotDifficulty } = useGameStore();

  if (!room) return null;

  const currentPlayer = room.players.find(p => p.id === currentPlayerId);
  const isHost = currentPlayer?.isHost || network.isHost;
  const canStart = room.players.length >= 3 && 
    room.players.length >= room.settings.impostorCount + room.settings.doctorCount + 1;

  const copyRoomCode = () => {
    navigator.clipboard.writeText(room.code);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-950 via-purple-950/40 to-gray-950 flex flex-col items-center p-4 relative overflow-hidden">
      <ParticlesBackground variant="home" />
      
      <div className="relative z-10 w-full max-w-lg">
        {/* Header */}
        <div className="flex items-center justify-between mb-6 mt-4">
          <button onClick={backToLobby} className="text-gray-400 hover:text-white transition-colors">
            ← Leave
          </button>
          <div className="text-center">
            <h2 className="text-2xl font-bold text-white">Game Lobby</h2>
            <div className="flex items-center gap-2 justify-center mt-1">
              <span className="text-gray-400 text-sm">Room Code:</span>
              <button 
                onClick={copyRoomCode}
                className="bg-purple-600/40 px-3 py-1 rounded-lg text-purple-200 font-mono tracking-wider text-lg font-bold border border-purple-500/30 hover:bg-purple-600/60 transition-colors flex items-center gap-1"
                title="Click to copy"
              >
                {room.code}
                <span className="text-xs">📋</span>
              </button>
            </div>
            <p className="text-gray-500 text-xs mt-1">Share this code with friends to join!</p>
          </div>
          <div className="w-12" />
        </div>

        {/* Connection Status */}
        <div className="flex items-center justify-center gap-2 mb-4">
          <div className={`w-2 h-2 rounded-full ${network.isConnected ? 'bg-green-500' : 'bg-red-500'} animate-pulse`} />
          <span className="text-gray-400 text-xs">
            {network.isHost ? 'Hosting' : 'Connected'} • {network.connectedPeers} peer{network.connectedPeers !== 1 ? 's' : ''}
          </span>
        </div>

        {/* Settings Display */}
        <div className="bg-gray-900/60 backdrop-blur-sm rounded-xl p-4 mb-4 border border-gray-700/50">
          <div className="flex justify-around text-center text-sm">
            <div>
              <span className="text-red-400">🔪 {room.settings.impostorCount}</span>
              <span className="text-gray-500 ml-1">Imp</span>
            </div>
            <div>
              <span className="text-cyan-400">🛡️ {room.settings.doctorCount}</span>
              <span className="text-gray-500 ml-1">Doc</span>
            </div>
            <div>
              <span className="text-gray-300">👥 {room.players.length}/{room.settings.maxPlayers}</span>
              <span className="text-gray-500 ml-1">Players</span>
            </div>
          </div>
        </div>

        {/* Bot Difficulty (Host only) */}
        {isHost && (
          <div className="bg-gray-900/60 backdrop-blur-sm rounded-xl p-3 mb-4 border border-gray-700/50">
            <div className="flex items-center justify-between">
              <span className="text-gray-400 text-sm">🤖 Bot AI Level:</span>
              <span className={`font-bold ${difficultyColors[botDifficulty]}`}>{difficultyLabels[botDifficulty]}</span>
            </div>
            <input
              type="range"
              min={1}
              max={5}
              value={botDifficulty}
              onChange={(e) => setBotDifficulty(parseInt(e.target.value) as 1|2|3|4|5)}
              className="w-full mt-2 accent-purple-500 h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer"
            />
          </div>
        )}

        {/* Players List */}
        <div className="space-y-2 mb-6">
          {room.players.map((player) => (
            <div
              key={player.id}
              className={`flex items-center gap-3 p-3 rounded-xl border transition-all ${
                player.id === currentPlayerId
                  ? 'bg-purple-900/30 border-purple-500/40 shadow-lg shadow-purple-500/10'
                  : 'bg-gray-900/40 border-gray-700/30'
              }`}
            >
              <div className="w-12 h-12 rounded-full bg-gray-800 flex items-center justify-center text-2xl overflow-hidden border-2 border-gray-600 shrink-0">
                {player.avatar?.startsWith('data:') ? (
                  <img src={player.avatar} alt="avatar" className="w-full h-full object-cover" />
                ) : (
                  <span>{player.avatar || '😎'}</span>
                )}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="text-white font-medium truncate">{player.name}</span>
                  {player.isHost && (
                    <span className="text-yellow-400 text-xs bg-yellow-400/10 px-2 py-0.5 rounded-full">👑 Host</span>
                  )}
                  {player.isBot && (
                    <span className={`text-xs px-2 py-0.5 rounded-full ${difficultyColors[player.botDifficulty]} bg-gray-700`}>
                      🤖 {difficultyLabels[player.botDifficulty]}
                    </span>
                  )}
                  {player.id === currentPlayerId && (
                    <span className="text-purple-400 text-xs">← You</span>
                  )}
                </div>
              </div>
              {isHost && player.isBot && (
                <button
                  onClick={() => removeBot(player.id)}
                  className="text-red-400 hover:text-red-300 text-sm px-2 py-1 rounded hover:bg-red-400/10 transition-colors"
                >
                  ✕
                </button>
              )}
            </div>
          ))}
        </div>

        {/* Actions */}
        {isHost && (
          <div className="space-y-3">
            {room.players.length < room.settings.maxPlayers && (
              <button
                onClick={addBot}
                className="w-full py-3 bg-gray-800 hover:bg-gray-700 text-gray-300 font-medium rounded-xl transition-all border border-gray-600 hover:border-gray-500"
              >
                🤖 Add Bot ({difficultyLabels[botDifficulty]})
              </button>
            )}
            <button
              onClick={startGame}
              disabled={!canStart}
              className="w-full py-4 bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-500 hover:to-emerald-500 disabled:from-gray-600 disabled:to-gray-600 text-white font-bold rounded-xl transition-all hover:scale-[1.02] shadow-lg shadow-green-600/30 disabled:shadow-none text-lg"
            >
              {canStart ? '▶ Start Game' : `Need at least ${room.settings.impostorCount + room.settings.doctorCount + 1} players`}
            </button>
          </div>
        )}

        {!isHost && (
          <div className="text-center py-4">
            <div className="flex items-center justify-center gap-2 text-gray-400">
              <div className="w-4 h-4 border-2 border-gray-500 border-t-purple-400 rounded-full animate-spin" />
              Waiting for host to start the game...
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
