import { useEffect, useState } from 'react';
import { Player } from '../types';
import ParticlesBackground from './ParticlesBackground';

interface Props {
  player: Player;
  onDone: () => void;
}

export default function RoleReveal({ player, onDone }: Props) {
  const [step, setStep] = useState(0);

  useEffect(() => {
    const t1 = setTimeout(() => setStep(1), 500);
    const t2 = setTimeout(() => setStep(2), 1500);
    const t3 = setTimeout(() => {
      setStep(3);
      onDone();
    }, 4000);
    return () => {
      clearTimeout(t1);
      clearTimeout(t2);
      clearTimeout(t3);
    };
  }, [onDone]);

  const roleConfig = {
    impostor: {
      icon: '🔪',
      title: 'IMPOSTOR',
      subtitle: 'You are the shadow in the night',
      desc: 'Kill players one by one. Win when only you remain.',
      bgGradient: 'from-black via-red-950 to-black',
      textColor: 'text-red-400',
      borderColor: 'border-red-500',
      particleVariant: 'impostor' as const,
    },
    doctor: {
      icon: '🛡️',
      title: 'DOCTOR',
      subtitle: 'Guardian of the innocent',
      desc: 'Give 2 shields each round. Predict who the impostor will target!',
      bgGradient: 'from-black via-cyan-950 to-black',
      textColor: 'text-cyan-400',
      borderColor: 'border-cyan-500',
      particleVariant: 'doctor' as const,
    },
    innocent: {
      icon: '👤',
      title: 'INNOCENT',
      subtitle: 'Survive the darkness',
      desc: 'Stay alive! Hope the doctor protects you.',
      bgGradient: 'from-black via-gray-900 to-black',
      textColor: 'text-gray-300',
      borderColor: 'border-gray-500',
      particleVariant: 'night' as const,
    },
  };

  const config = roleConfig[player.role];

  return (
    <div className={`fixed inset-0 z-[100] bg-gradient-to-br ${config.bgGradient} flex items-center justify-center transition-all duration-1000`}>
      <ParticlesBackground variant={config.particleVariant} />
      
      <div className="relative z-10 text-center">
        {step === 0 && (
          <div className="animate-pulse">
            <p className="text-gray-600 text-lg">Your fate is being decided...</p>
          </div>
        )}

        {step >= 1 && (
          <div className="animate-fade-in">
            <div className={`text-8xl md:text-9xl mb-6 ${step >= 2 ? '' : 'animate-bounce'}`}>
              {config.icon}
            </div>
          </div>
        )}

        {step >= 2 && (
          <div className="animate-fade-in">
            <h1 className={`text-5xl md:text-6xl font-black ${config.textColor} mb-3 tracking-wider`}>
              {config.title}
            </h1>
            <p className={`${config.textColor} opacity-70 text-lg mb-2`}>{config.subtitle}</p>
            <p className="text-gray-500 text-sm max-w-xs mx-auto mb-8">{config.desc}</p>
            
            <div className={`inline-block px-6 py-3 rounded-xl bg-black/40 border ${config.borderColor}/30`}>
              {player.role === 'impostor' && (
                <p className="text-red-300/70 text-xs">💡 During your turn, pick one player to eliminate</p>
              )}
              {player.role === 'doctor' && (
                <p className="text-cyan-300/70 text-xs">💡 Give shields to 1 player (2 shields) or 2 players (1 each)</p>
              )}
              {player.role === 'innocent' && (
                <p className="text-gray-400 text-xs">💡 Your screen will be dark during the night phase</p>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
