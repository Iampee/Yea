import { useState, useEffect } from 'react';
import { useGameStore } from '../store';
import ParticlesBackground from './ParticlesBackground';
import { playCountdown, playNightFall } from '../sounds';

export default function NightPhase() {
  const { room, currentPlayerId } = useGameStore();
  const [countdown, setCountdown] = useState(5);

  useEffect(() => {
    if (!room || room.phase !== 'night-start') return;
    setCountdown(5);
    playNightFall();
    const timer = setInterval(() => {
      setCountdown(prev => {
        if (prev <= 1) {
          clearInterval(timer);
          return 0;
        }
        playCountdown();
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(timer);
  }, [room?.phase, room?.round]);

  if (!room) return null;

  const currentPlayer = room.players.find(p => p.id === currentPlayerId);
  const isDead = currentPlayer && !currentPlayer.isAlive;
  const roleEmoji = currentPlayer?.role === 'impostor' ? '🔪' : currentPlayer?.role === 'doctor' ? '🛡️' : '👤';

  return (
    <div className="min-h-screen bg-black flex flex-col items-center justify-center p-4 relative overflow-hidden">
      <ParticlesBackground variant="night" />

      {/* Gradient vignette */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_transparent_30%,_black_100%)]" />

      <div className="relative z-10 text-center">
        <div className="text-7xl mb-6 animate-bounce" style={{ animationDuration: '2s' }}>🌙</div>
        <h1 className="text-4xl md:text-5xl font-bold text-gray-200 mb-3">
          Night Falls...
        </h1>
        <p className="text-gray-500 text-lg mb-2">
          Round {room.round} — Everyone close your eyes
        </p>

        {currentPlayer && (
          <div className={`inline-block px-4 py-2 rounded-full mb-8 text-sm ${
            isDead ? 'bg-gray-900/30 text-gray-700 border border-gray-800/20' :
            currentPlayer.role === 'impostor' ? 'bg-red-900/20 text-red-400/70 border border-red-500/20' :
            currentPlayer.role === 'doctor' ? 'bg-cyan-900/20 text-cyan-400/70 border border-cyan-500/20' :
            'bg-gray-800/30 text-gray-500 border border-gray-700/20'
          }`}>
            {isDead ? '💀 You are eliminated — spectating' : <>{roleEmoji} You are the <span className="font-bold capitalize">{currentPlayer.role}</span></>}
          </div>
        )}

        <div className="relative">
          <div className={`text-8xl font-black tabular-nums transition-all duration-300 ${
            countdown <= 2 ? 'text-red-500 scale-110' : 'text-purple-400'
          }`}>
            {countdown}
          </div>
          <div key={countdown} className="absolute inset-0 flex items-center justify-center">
            <div className="w-20 h-20 rounded-full border-2 border-purple-500/30 animate-ripple" />
          </div>
        </div>

        <p className="text-gray-700 mt-6 text-sm">
          {currentPlayer?.role === 'impostor'
            ? 'Prepare to choose your victim...'
            : currentPlayer?.role === 'doctor'
            ? 'Get ready to protect someone...'
            : 'Pray the doctor protects you...'}
        </p>
      </div>
    </div>
  );
}
