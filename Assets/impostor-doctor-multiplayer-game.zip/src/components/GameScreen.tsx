import { useState, useCallback } from 'react';
import { useGameStore } from '../store';
import NightPhase from './NightPhase';
import ImpostorTurn from './ImpostorTurn';
import DoctorTurn from './DoctorTurn';
import RevealPhase from './RevealPhase';
import VotingPhase from './VotingPhase';
import VoteResultPhase from './VoteResultPhase';
import GameOver from './GameOver';
import RoleReveal from './RoleReveal';

export default function GameScreen() {
  const { room, currentPlayerId } = useGameStore();
  const [showRoleReveal, setShowRoleReveal] = useState(true);

  const handleRoleRevealDone = useCallback(() => {
    setTimeout(() => setShowRoleReveal(false), 500);
  }, []);

  if (!room) return null;

  const currentPlayer = room.players.find(p => p.id === currentPlayerId);
  if (!currentPlayer) return null;

  const roleInfo = {
    impostor: { icon: '🔪', label: 'IMPOSTOR', color: 'text-red-400', bg: 'bg-red-900/50' },
    doctor: { icon: '🛡️', label: 'DOCTOR', color: 'text-cyan-400', bg: 'bg-cyan-900/50' },
    innocent: { icon: '👤', label: 'INNOCENT', color: 'text-gray-300', bg: 'bg-gray-800' },
  }[currentPlayer.role];

  const showHud = !['game-over'].includes(room.phase);
  const phaseLabel = {
    'night-start': '🌙 Night',
    'impostor-turn': '🔪 Impostor',
    'doctor-turn': '🛡️ Doctor',
    'reveal': '☀️ Dawn',
    'voting': '🗳️ Voting',
    'vote-result': '📊 Results',
    'game-over': '',
    'lobby': '',
  }[room.phase];

  return (
    <div className="relative game-area">
      {/* Role Reveal Overlay */}
      {showRoleReveal && room.phase === 'night-start' && room.round === 1 && (
        <RoleReveal player={currentPlayer} onDone={handleRoleRevealDone} />
      )}

      {/* HUD Overlay */}
      {showHud && (
        <div className="fixed top-0 left-0 right-0 z-40 flex items-center justify-between px-3 py-1.5 bg-gray-950/90 backdrop-blur-md border-b border-gray-800/50">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-full bg-gray-800 flex items-center justify-center text-sm overflow-hidden border border-gray-600 shrink-0">
              {currentPlayer.avatar?.startsWith('data:') ? (
                <img src={currentPlayer.avatar} alt="" className="w-full h-full object-cover" />
              ) : (
                <span className="text-xs">{currentPlayer.avatar}</span>
              )}
            </div>
            <span className={`text-xs font-bold px-1.5 py-0.5 rounded ${roleInfo.bg} ${roleInfo.color}`}>
              {roleInfo.icon} {roleInfo.label}
            </span>
            {!currentPlayer.isAlive && (
              <span className="text-xs text-red-400/60 font-medium">💀 DEAD</span>
            )}
          </div>
          <div className="flex items-center gap-2 text-xs">
            {phaseLabel && <span className="text-gray-500">{phaseLabel}</span>}
            <span className="text-gray-700">|</span>
            <span className="text-amber-400/80 font-mono">R{room.round}</span>
            <span className="text-gray-700">|</span>
            <span className="text-green-400/80">{room.players.filter(p => p.isAlive).length}👤</span>
            {/* Only YOU see YOUR shields */}
            {currentPlayer.shields > 0 && currentPlayer.isAlive && (
              <>
                <span className="text-gray-700">|</span>
                <span className="text-cyan-400">🛡️</span>
                <span className="text-cyan-300 font-bold">×{currentPlayer.shields}</span>
              </>
            )}
          </div>
        </div>
      )}

      {/* Phase Content */}
      <div className={showHud ? 'pt-10' : ''}>
        {room.phase === 'night-start' && <NightPhase />}
        {room.phase === 'impostor-turn' && <ImpostorTurn />}
        {room.phase === 'doctor-turn' && <DoctorTurn />}
        {room.phase === 'reveal' && <RevealPhase />}
        {room.phase === 'voting' && <VotingPhase />}
        {room.phase === 'vote-result' && <VoteResultPhase />}
        {room.phase === 'game-over' && <GameOver />}
      </div>
    </div>
  );
}
