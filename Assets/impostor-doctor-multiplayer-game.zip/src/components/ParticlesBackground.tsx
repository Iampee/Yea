import { useMemo, useCallback } from 'react';
import Particles from '@tsparticles/react';
import type { ISourceOptions } from '@tsparticles/engine';

interface Props {
  variant: 'home' | 'impostor' | 'doctor' | 'night' | 'voting' | 'victory-red' | 'victory-cyan';
}

export default function ParticlesBackground({ variant }: Props) {
  const particlesLoaded = useCallback(async () => {}, []);

  const options: ISourceOptions = useMemo(() => {
    const baseOptions: ISourceOptions = {
      fullScreen: { enable: false },
      fpsLimit: 60,
      detectRetina: true,
    };

    switch (variant) {
      case 'home':
        return {
          ...baseOptions,
          particles: {
            number: { value: 50, density: { enable: true } },
            color: { value: ['#8b5cf6', '#ec4899', '#06b6d4', '#ef4444'] },
            shape: { type: 'circle' },
            opacity: { value: { min: 0.1, max: 0.5 }, animation: { enable: true, speed: 1, sync: false } },
            size: { value: { min: 1, max: 4 } },
            move: { enable: true, speed: 0.5, direction: 'none', outModes: 'out' },
            links: { enable: true, distance: 150, color: '#8b5cf6', opacity: 0.1, width: 1 },
          },
        };

      case 'impostor':
        return {
          ...baseOptions,
          particles: {
            number: { value: 80, density: { enable: true } },
            color: { value: ['#ef4444', '#dc2626', '#991b1b', '#7f1d1d'] },
            shape: { type: 'circle' },
            opacity: { value: { min: 0.2, max: 0.8 }, animation: { enable: true, speed: 2, sync: false } },
            size: { value: { min: 1, max: 6 } },
            move: { enable: true, speed: 1.5, direction: 'none', outModes: 'out', random: true },
            shadow: { enable: true, color: '#ef4444', blur: 10 },
          },
          interactivity: {
            events: { onHover: { enable: true, mode: 'repulse' } },
            modes: { repulse: { distance: 100, duration: 0.4 } },
          },
        };

      case 'doctor':
        return {
          ...baseOptions,
          particles: {
            number: { value: 60, density: { enable: true } },
            color: { value: ['#06b6d4', '#22d3ee', '#67e8f9', '#0891b2'] },
            shape: { type: 'circle' },
            opacity: { value: { min: 0.3, max: 0.9 }, animation: { enable: true, speed: 1.5, sync: false } },
            size: { value: { min: 2, max: 8 } },
            move: { enable: true, speed: 0.8, direction: 'top', outModes: 'out' },
            shadow: { enable: true, color: '#06b6d4', blur: 15 },
          },
        };

      case 'night':
        return {
          ...baseOptions,
          particles: {
            number: { value: 100, density: { enable: true } },
            color: { value: '#ffffff' },
            shape: { type: 'circle' },
            opacity: { value: { min: 0.1, max: 0.8 }, animation: { enable: true, speed: 0.5, sync: false } },
            size: { value: { min: 0.5, max: 2 } },
            move: { enable: true, speed: 0.1, direction: 'none', outModes: 'out' },
            twinkle: { particles: { enable: true, frequency: 0.05, opacity: 1 } },
          },
        };

      case 'voting':
        return {
          ...baseOptions,
          particles: {
            number: { value: 30, density: { enable: true } },
            color: { value: ['#6366f1', '#8b5cf6', '#a855f7'] },
            shape: { type: 'circle' },
            opacity: { value: { min: 0.1, max: 0.4 }, animation: { enable: true, speed: 1, sync: false } },
            size: { value: { min: 1, max: 3 } },
            move: { enable: true, speed: 0.3, direction: 'none', outModes: 'out' },
          },
        };

      case 'victory-red':
        return {
          ...baseOptions,
          particles: {
            number: { value: 70, density: { enable: true } },
            color: { value: ['#ef4444', '#dc2626', '#f97316', '#fbbf24'] },
            shape: { type: ['circle', 'square'] },
            opacity: { value: { min: 0.3, max: 1 }, animation: { enable: true, speed: 2, sync: false } },
            size: { value: { min: 2, max: 8 } },
            move: { enable: true, speed: 2, direction: 'none', outModes: 'out', random: true },
          },
        };

      case 'victory-cyan':
        return {
          ...baseOptions,
          particles: {
            number: { value: 70, density: { enable: true } },
            color: { value: ['#06b6d4', '#22d3ee', '#10b981', '#3b82f6'] },
            shape: { type: ['circle', 'square'] },
            opacity: { value: { min: 0.3, max: 1 }, animation: { enable: true, speed: 2, sync: false } },
            size: { value: { min: 2, max: 8 } },
            move: { enable: true, speed: 2, direction: 'none', outModes: 'out', random: true },
          },
        };

      default:
        return baseOptions;
    }
  }, [variant]);

  return (
    <Particles
      className="absolute inset-0 -z-10"
      options={options}
      particlesLoaded={particlesLoaded}
    />
  );
}
