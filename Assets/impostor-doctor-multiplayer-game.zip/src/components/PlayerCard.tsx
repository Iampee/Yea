import { Player } from '../types';

interface Props {
  player: Player;
  onClick?: () => void;
  selected?: boolean;
  isTarget?: boolean;
  showRole?: boolean;
  showMyShields?: boolean; // only true if this is the current player
  isDead?: boolean;
  glowColor?: string;
  disabled?: boolean;
  size?: 'sm' | 'md' | 'lg';
  voteCount?: number;
  hasVoted?: boolean;
}

export default function PlayerCard({
  player,
  onClick,
  selected = false,
  isTarget = false,
  showRole = false,
  showMyShields = false,
  isDead = false,
  glowColor,
  disabled = false,
  size = 'md',
  voteCount,
  hasVoted = false,
}: Props) {
  const sizeClasses = { sm: 'w-14 h-14 text-lg', md: 'w-20 h-20 text-3xl', lg: 'w-24 h-24 text-4xl' };
  const nameSizes = { sm: 'text-xs', md: 'text-sm', lg: 'text-base' };
  const roleColors = { impostor: 'text-red-400', doctor: 'text-cyan-400', innocent: 'text-gray-400' };
  const roleIcons = { impostor: '🔪', doctor: '🛡️', innocent: '👤' };

  return (
    <button
      onClick={onClick}
      disabled={disabled || !onClick}
      className={`flex flex-col items-center gap-1 p-2 rounded-xl transition-all duration-300 relative ${
        onClick && !disabled ? 'cursor-pointer hover:scale-105 active:scale-95' : 'cursor-default'
      } ${selected ? 'ring-2 ring-offset-2 ring-offset-gray-900 scale-105' : ''} ${
        selected && glowColor === 'red' ? 'ring-red-500 bg-red-900/30' : ''
      } ${selected && glowColor === 'cyan' ? 'ring-cyan-500 bg-cyan-900/30' : ''
      } ${selected && glowColor === 'green' ? 'ring-green-500 bg-green-900/30' : ''
      } ${selected && glowColor === 'amber' ? 'ring-amber-500 bg-amber-900/30' : ''
      } ${isTarget ? 'animate-pulse' : ''} ${isDead ? 'opacity-40 grayscale' : ''} ${disabled ? 'opacity-50' : ''}`}
    >
      <div className={`relative ${sizeClasses[size]} rounded-full bg-gray-800 flex items-center justify-center overflow-hidden border-2 ${
        isDead ? 'border-gray-600' :
        selected ? (
          glowColor === 'red' ? 'border-red-500 shadow-lg shadow-red-500/50' :
          glowColor === 'cyan' ? 'border-cyan-500 shadow-lg shadow-cyan-500/50' :
          glowColor === 'amber' ? 'border-amber-500 shadow-lg shadow-amber-500/50' :
          'border-green-500 shadow-lg shadow-green-500/50'
        ) : 'border-gray-600'
      }`}>
        {player.avatar?.startsWith('data:') ? (
          <img src={player.avatar} alt="avatar" className="w-full h-full object-cover" />
        ) : (
          <span>{player.avatar || '😎'}</span>
        )}
        {isDead && (
          <div className="absolute inset-0 bg-black/60 flex items-center justify-center">
            <span className="text-3xl">💀</span>
          </div>
        )}
      </div>

      <span className={`${nameSizes[size]} font-medium text-white truncate max-w-20 text-center`}>
        {player.name}
      </span>

      {showRole && (
        <span className={`text-xs ${roleColors[player.role]}`}>
          {roleIcons[player.role]} {player.role}
        </span>
      )}

      {/* Only show YOUR OWN shields */}
      {showMyShields && player.shields > 0 && player.isAlive && (
        <div className="flex gap-0.5">
          {[...Array(player.shields)].map((_, i) => (
            <span key={i} className="text-xs animate-pulse">🛡️</span>
          ))}
        </div>
      )}

      {/* Vote count badge */}
      {voteCount !== undefined && voteCount > 0 && (
        <div className="absolute -top-1 -right-1 bg-amber-500 text-black text-xs w-6 h-6 rounded-full flex items-center justify-center font-bold shadow-lg shadow-amber-500/50 animate-fade-in">
          {voteCount}
        </div>
      )}

      {/* Voted indicator */}
      {hasVoted && (
        <div className="absolute -bottom-0.5 left-1/2 -translate-x-1/2">
          <span className="text-xs text-green-400">✓</span>
        </div>
      )}
    </button>
  );
}
