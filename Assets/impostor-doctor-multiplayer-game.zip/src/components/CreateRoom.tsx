import { useState } from 'react';
import { useGameStore } from '../store';
import ParticlesBackground from './ParticlesBackground';

export default function CreateRoom() {
  const { createRoom, setScreen, isConnecting, connectionError } = useGameStore();
  const [maxPlayers, setMaxPlayers] = useState(6);
  const [impostorCount, setImpostorCount] = useState(1);
  const [doctorCount, setDoctorCount] = useState(1);
  const [localError, setLocalError] = useState('');

  const minPlayers = impostorCount + doctorCount + 1;

  const handleCreate = async () => {
    setLocalError('');
    try {
      await createRoom({
        maxPlayers: Math.max(maxPlayers, minPlayers),
        impostorCount,
        doctorCount,
      });
    } catch (err) {
      setLocalError(err instanceof Error ? err.message : 'Failed to create room');
    }
  };

  const displayError = localError || connectionError;

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-950 via-red-950/30 to-gray-950 flex flex-col items-center justify-center p-4 relative overflow-hidden">
      <ParticlesBackground variant="impostor" />
      <div className="relative z-10 bg-gray-900/80 backdrop-blur-xl border border-red-500/30 rounded-2xl p-6 w-full max-w-md shadow-2xl shadow-red-900/20">
        <button
          onClick={() => setScreen('home')}
          className="text-gray-400 hover:text-white mb-4 flex items-center gap-1 transition-colors"
          disabled={isConnecting}
        >
          ← Back
        </button>

        <h2 className="text-3xl font-bold text-white text-center mb-6">
          🏠 Create Room
        </h2>

        {displayError && (
          <div className="bg-red-900/30 border border-red-500/50 text-red-300 px-4 py-2 rounded-lg mb-4 text-sm">
            {displayError}
          </div>
        )}

        {/* Max Players */}
        <div className="mb-5">
          <label className="text-gray-300 text-sm mb-2 block font-medium">
            Max Players: <span className="text-red-400 font-bold text-lg">{maxPlayers}</span>
          </label>
          <input
            type="range"
            min={3}
            max={20}
            value={maxPlayers}
            onChange={(e) => {
              const val = parseInt(e.target.value);
              setMaxPlayers(val);
              if (impostorCount + doctorCount >= val) {
                setImpostorCount(1);
                setDoctorCount(Math.min(doctorCount, val - 2));
              }
            }}
            className="w-full accent-red-500 h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer"
            disabled={isConnecting}
          />
          <div className="flex justify-between text-gray-500 text-xs mt-1">
            <span>3</span><span>20</span>
          </div>
        </div>

        {/* Impostor Count */}
        <div className="mb-5">
          <label className="text-gray-300 text-sm mb-2 block font-medium">
            Impostors: <span className="text-red-500 font-bold text-lg">{impostorCount}</span>
          </label>
          <input
            type="range"
            min={1}
            max={Math.max(1, maxPlayers - doctorCount - 1)}
            value={impostorCount}
            onChange={(e) => setImpostorCount(parseInt(e.target.value))}
            className="w-full accent-red-600 h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer"
            disabled={isConnecting}
          />
          <div className="flex justify-between text-gray-500 text-xs mt-1">
            <span>1</span><span>{Math.max(1, maxPlayers - doctorCount - 1)}</span>
          </div>
        </div>

        {/* Doctor Count */}
        <div className="mb-5">
          <label className="text-gray-300 text-sm mb-2 block font-medium">
            Doctors: <span className="text-cyan-400 font-bold text-lg">{doctorCount}</span>
          </label>
          <input
            type="range"
            min={1}
            max={Math.max(1, maxPlayers - impostorCount - 1)}
            value={doctorCount}
            onChange={(e) => setDoctorCount(parseInt(e.target.value))}
            className="w-full accent-cyan-500 h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer"
            disabled={isConnecting}
          />
          <div className="flex justify-between text-gray-500 text-xs mt-1">
            <span>1</span><span>{Math.max(1, maxPlayers - impostorCount - 1)}</span>
          </div>
        </div>

        {/* Role Summary */}
        <div className="bg-gray-800/80 rounded-xl p-4 mb-6 border border-gray-700">
          <h3 className="text-sm text-gray-400 mb-2 font-medium">Role Distribution</h3>
          <div className="flex justify-around text-center">
            <div>
              <div className="text-2xl">🔪</div>
              <div className="text-red-400 font-bold">{impostorCount}</div>
              <div className="text-gray-500 text-xs">Impostor{impostorCount > 1 ? 's' : ''}</div>
            </div>
            <div>
              <div className="text-2xl">🛡️</div>
              <div className="text-cyan-400 font-bold">{doctorCount}</div>
              <div className="text-gray-500 text-xs">Doctor{doctorCount > 1 ? 's' : ''}</div>
            </div>
            <div>
              <div className="text-2xl">👤</div>
              <div className="text-gray-300 font-bold">{Math.max(0, maxPlayers - impostorCount - doctorCount)}</div>
              <div className="text-gray-500 text-xs">Innocent</div>
            </div>
          </div>
        </div>

        <button
          onClick={handleCreate}
          disabled={isConnecting}
          className="w-full py-4 bg-gradient-to-r from-red-600 to-orange-600 hover:from-red-500 hover:to-orange-500 disabled:from-gray-600 disabled:to-gray-600 text-white font-bold rounded-xl transition-all hover:scale-[1.02] shadow-lg shadow-red-600/30 disabled:shadow-none text-lg flex items-center justify-center gap-2"
        >
          {isConnecting ? (
            <>
              <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
              Creating Room...
            </>
          ) : (
            'Create Room 🚀'
          )}
        </button>
      </div>
    </div>
  );
}
