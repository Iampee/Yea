import { useState, useRef } from 'react';
import { useGameStore } from '../store';
import ParticlesBackground from './ParticlesBackground';

const LOGO_URL = 'https://raw.githubusercontent.com/Iampee/Yea/main/Assets/1.png';

export default function HomeScreen() {
  const { playerName, playerAvatar, setPlayerName, setPlayerAvatar, setScreen, botDifficulty, setBotDifficulty } = useGameStore();
  const [editingProfile, setEditingProfile] = useState(!playerName);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const cameraInputRef = useRef<HTMLInputElement>(null);

  const defaultAvatars = ['😎', '🥷', '🧙', '👻', '🦹', '🤠', '🧛', '🧟', '🎃', '🐱', '🦊', '🐺'];

  const difficultyLabels = ['', 'Easy', 'Normal', 'Hard', 'Expert', 'Impossible'];
  const difficultyColors = ['', 'text-green-400', 'text-yellow-400', 'text-orange-400', 'text-red-400', 'text-purple-400'];

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (ev) => {
        const img = new Image();
        img.onload = () => {
          const canvas = document.createElement('canvas');
          canvas.width = 128;
          canvas.height = 128;
          const ctx = canvas.getContext('2d')!;
          const size = Math.min(img.width, img.height);
          const sx = (img.width - size) / 2;
          const sy = (img.height - size) / 2;
          ctx.drawImage(img, sx, sy, size, size, 0, 0, 128, 128);
          setPlayerAvatar(canvas.toDataURL('image/jpeg', 0.8));
        };
        img.src = ev.target?.result as string;
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <div className="min-h-screen bg-black flex flex-col items-center justify-center p-4 relative overflow-hidden">
      <ParticlesBackground variant="home" />

      {/* Logo from GitHub */}
      <div className="relative z-10 mb-8">
        <img 
          src={LOGO_URL} 
          alt="Shadow Among Us" 
          className="w-64 md:w-80 drop-shadow-2xl rounded-2xl"
          style={{ filter: 'brightness(1.1) contrast(1.05) saturate(1.1)' }}
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/30 via-transparent to-transparent rounded-2xl pointer-events-none" />
      </div>

      {/* Profile Section */}
      {editingProfile || !playerName ? (
        <div className="relative z-10 bg-gray-900/80 backdrop-blur-xl border border-purple-500/30 rounded-2xl p-6 w-full max-w-md shadow-2xl shadow-purple-900/30">
          <h2 className="text-2xl font-bold text-white text-center mb-6">Create Your Profile</h2>

          <div className="flex flex-col items-center mb-6">
            <div className="w-24 h-24 rounded-full border-4 border-purple-500 bg-gray-800 flex items-center justify-center text-5xl overflow-hidden mb-3 shadow-lg shadow-purple-500/30">
              {playerAvatar?.startsWith('data:') ? (
                <img src={playerAvatar} alt="avatar" className="w-full h-full object-cover" />
              ) : (
                <span>{playerAvatar || '😎'}</span>
              )}
            </div>
            
            <div className="flex gap-2 mb-3 flex-wrap justify-center">
              {defaultAvatars.map(emoji => (
                <button
                  key={emoji}
                  onClick={() => setPlayerAvatar(emoji)}
                  className={`w-10 h-10 rounded-lg text-2xl flex items-center justify-center transition-all hover:scale-110 ${
                    playerAvatar === emoji 
                      ? 'bg-purple-600 ring-2 ring-purple-400 shadow-lg shadow-purple-500/50' 
                      : 'bg-gray-700 hover:bg-gray-600'
                  }`}
                >
                  {emoji}
                </button>
              ))}
            </div>

            <div className="flex gap-2">
              <button onClick={() => fileInputRef.current?.click()} className="px-4 py-2 bg-gray-700 hover:bg-gray-600 text-white rounded-lg text-sm transition-all hover:scale-105">
                📁 Gallery
              </button>
              <button onClick={() => cameraInputRef.current?.click()} className="px-4 py-2 bg-gray-700 hover:bg-gray-600 text-white rounded-lg text-sm transition-all hover:scale-105">
                📷 Camera
              </button>
            </div>
            <input ref={fileInputRef} type="file" accept="image/*" className="hidden" onChange={handleImageUpload} />
            <input ref={cameraInputRef} type="file" accept="image/*" capture="user" className="hidden" onChange={handleImageUpload} />
          </div>

          <div className="mb-6">
            <label className="text-gray-400 text-sm mb-1 block">Player Name</label>
            <input
              type="text"
              value={playerName}
              onChange={(e) => setPlayerName(e.target.value)}
              placeholder="Enter your name..."
              maxLength={16}
              className="w-full bg-gray-800 border border-gray-600 focus:border-purple-500 focus:ring-2 focus:ring-purple-500/50 text-white px-4 py-3 rounded-xl outline-none transition-all text-lg"
            />
          </div>

          <button
            onClick={() => { if (playerName.trim()) setEditingProfile(false); }}
            disabled={!playerName.trim()}
            className="w-full py-3 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-500 hover:to-pink-500 disabled:from-gray-600 disabled:to-gray-600 text-white font-bold rounded-xl transition-all hover:scale-[1.02] shadow-lg shadow-purple-600/30 disabled:shadow-none text-lg"
          >
            Continue
          </button>
        </div>
      ) : (
        <div className="relative z-10 flex flex-col items-center gap-4 w-full max-w-md">
          {/* Mini profile */}
          <div className="flex items-center gap-3 bg-gray-900/60 backdrop-blur-sm px-5 py-3 rounded-full border border-gray-700 mb-2 cursor-pointer hover:border-purple-500/50 transition-all" onClick={() => setEditingProfile(true)}>
            <div className="w-10 h-10 rounded-full bg-gray-800 flex items-center justify-center text-xl overflow-hidden border-2 border-purple-500">
              {playerAvatar?.startsWith('data:') ? (
                <img src={playerAvatar} alt="avatar" className="w-full h-full object-cover" />
              ) : (
                <span>{playerAvatar || '😎'}</span>
              )}
            </div>
            <span className="text-white font-semibold">{playerName}</span>
            <span className="text-gray-500 text-sm ml-1">✏️</span>
          </div>

          {/* Bot Difficulty Selector */}
          <div className="w-full bg-gray-900/60 backdrop-blur-sm rounded-xl p-4 border border-gray-700 mb-2">
            <label className="text-gray-400 text-sm mb-2 block">
              🤖 Bot Difficulty: <span className={`font-bold ${difficultyColors[botDifficulty]}`}>{difficultyLabels[botDifficulty]}</span>
            </label>
            <input
              type="range"
              min={1}
              max={5}
              value={botDifficulty}
              onChange={(e) => setBotDifficulty(parseInt(e.target.value) as 1|2|3|4|5)}
              className="w-full accent-purple-500 h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer"
            />
            <div className="flex justify-between text-gray-600 text-xs mt-1">
              <span>Easy</span>
              <span>Normal</span>
              <span>Hard</span>
              <span>Expert</span>
              <span>💀</span>
            </div>
          </div>

          <button onClick={() => setScreen('create')} className="w-full py-4 bg-gradient-to-r from-red-600 to-orange-600 hover:from-red-500 hover:to-orange-500 text-white font-bold rounded-2xl transition-all hover:scale-[1.02] shadow-2xl shadow-red-600/30 text-xl tracking-wide">
            🏠 Create Room
          </button>

          <button onClick={() => setScreen('join')} className="w-full py-4 bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white font-bold rounded-2xl transition-all hover:scale-[1.02] shadow-2xl shadow-blue-600/30 text-xl tracking-wide">
            🚪 Join Room
          </button>

          <div className="w-full border-t border-gray-800 pt-4 mt-1">
            <p className="text-gray-600 text-xs text-center mb-2">Quick start with {difficultyLabels[botDifficulty]} bots</p>
            <button
              onClick={async () => {
                const { createRoom, addBot } = useGameStore.getState();
                try {
                  await createRoom({ maxPlayers: 8, impostorCount: 1, doctorCount: 1 });
                  for (let i = 0; i < 5; i++) {
                    setTimeout(() => addBot(), i * 100);
                  }
                } catch (e) {
                  console.error('Failed to create room:', e);
                }
              }}
              className="w-full py-3 bg-gradient-to-r from-purple-700 to-violet-600 hover:from-purple-600 hover:to-violet-500 text-white font-bold rounded-2xl transition-all hover:scale-[1.02] shadow-xl shadow-purple-700/20 text-base tracking-wide"
            >
              ⚡ Quick Play (vs Bots)
            </button>
          </div>
        </div>
      )}


    </div>
  );
}
