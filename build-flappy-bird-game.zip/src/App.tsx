import FlappyBird from './FlappyBird';

function App() {
  return (
    <div className="w-screen h-screen bg-black flex items-center justify-center overflow-hidden">
      <FlappyBird />
    </div>
  );
}

export default App;
