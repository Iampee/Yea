import { useEffect, useRef, useCallback } from 'react';

// Asset base URL
const BASE = 'https://raw.githubusercontent.com/samuelcust/flappy-bird-assets/master/sprites';

// Game constants
const CANVAS_WIDTH = 288;
const CANVAS_HEIGHT = 512;
const GRAVITY = 0.45;
const JUMP_FORCE = -7.5;
const PIPE_SPEED = 2;
const PIPE_GAP = 115;
const PIPE_SPAWN_INTERVAL = 95; // frames
const BIRD_X = 60;
const BASE_HEIGHT = 112;
const GAME_HEIGHT = CANVAS_HEIGHT - BASE_HEIGHT;
const PIPE_WIDTH = 52;

type GameState = 'menu' | 'playing' | 'gameover';

interface Bird {
  y: number;
  velocity: number;
  frame: number;
  frameTimer: number;
  rotation: number;
}

interface Pipe {
  x: number;
  topHeight: number;
  scored: boolean;
}

interface GameData {
  state: GameState;
  bird: Bird;
  pipes: Pipe[];
  score: number;
  bestScore: number;
  baseX: number;
  pipeTimer: number;
  flashTimer: number;
  fallDone: boolean;
  menuBobTimer: number;
}

function loadImage(src: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => resolve(img);
    img.onerror = reject;
    img.src = src;
  });
}

export default function FlappyBird() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const gameRef = useRef<GameData>({
    state: 'menu',
    bird: { y: 200, velocity: 0, frame: 0, frameTimer: 0, rotation: 0 },
    pipes: [],
    score: 0,
    bestScore: 0,
    baseX: 0,
    pipeTimer: 0,
    flashTimer: 0,
    fallDone: false,
    menuBobTimer: 0,
  });
  const assetsRef = useRef<Record<string, HTMLImageElement>>({});
  const rafRef = useRef<number>(0);

  const resetBird = useCallback((): Bird => ({
    y: 200,
    velocity: 0,
    frame: 0,
    frameTimer: 0,
    rotation: 0,
  }), []);

  const handleInput = useCallback(() => {
    const game = gameRef.current;
    if (game.state === 'menu') {
      game.state = 'playing';
      game.bird = resetBird();
      game.bird.velocity = JUMP_FORCE;
      game.pipes = [];
      game.score = 0;
      game.pipeTimer = 0;
    } else if (game.state === 'playing') {
      game.bird.velocity = JUMP_FORCE;
    } else if (game.state === 'gameover' && game.fallDone) {
      game.state = 'menu';
      game.bird = resetBird();
      game.pipes = [];
      game.score = 0;
      game.pipeTimer = 0;
    }
  }, [resetBird]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d')!;
    ctx.imageSmoothingEnabled = false;

    // Load all assets
    const assetNames = [
      'background-day', 'base',
      'yellowbird-downflap', 'yellowbird-midflap', 'yellowbird-upflap',
      'pipe-green', 'gameover', 'message',
      '0', '1', '2', '3', '4', '5', '6', '7', '8', '9',
    ];

    const loadAll = async () => {
      const promises = assetNames.map(name =>
        loadImage(`${BASE}/${name}.png`).then(img => ({ name, img }))
      );
      const results = await Promise.all(promises);
      results.forEach(({ name, img }) => {
        assetsRef.current[name] = img;
      });
      startGame();
    };

    const birdFrames = ['yellowbird-midflap', 'yellowbird-downflap', 'yellowbird-midflap', 'yellowbird-upflap'];

    const spawnPipe = () => {
      const minTop = 60;
      const maxTop = GAME_HEIGHT - PIPE_GAP - 60;
      const topHeight = Math.floor(Math.random() * (maxTop - minTop)) + minTop;
      gameRef.current.pipes.push({ x: CANVAS_WIDTH + 10, topHeight, scored: false });
    };

    const update = () => {
      const game = gameRef.current;
      const bird = game.bird;

      // Animate base scroll
      if (game.state !== 'gameover') {
        game.baseX = (game.baseX + PIPE_SPEED) % 48;
      }

      if (game.state === 'menu') {
        game.menuBobTimer += 0.05;
        // Bird hover animation
        bird.frameTimer++;
        if (bird.frameTimer >= 8) {
          bird.frameTimer = 0;
          bird.frame = (bird.frame + 1) % 4;
        }
        bird.y = 200 + Math.sin(game.menuBobTimer) * 12;
        bird.rotation = 0;
      } else if (game.state === 'playing') {
        // Bird physics
        bird.velocity += GRAVITY;
        bird.y += bird.velocity;

        // Bird animation
        bird.frameTimer++;
        if (bird.frameTimer >= 5) {
          bird.frameTimer = 0;
          bird.frame = (bird.frame + 1) % 4;
        }

        // Bird rotation
        if (bird.velocity < -1) {
          bird.rotation = -25;
        } else if (bird.velocity < 3) {
          bird.rotation = 0;
        } else {
          bird.rotation = Math.min(90, bird.rotation + 4);
        }

        // Pipe spawning
        game.pipeTimer++;
        if (game.pipeTimer >= PIPE_SPAWN_INTERVAL) {
          game.pipeTimer = 0;
          spawnPipe();
        }

        // Move pipes
        game.pipes.forEach(pipe => {
          pipe.x -= PIPE_SPEED;
        });

        // Remove off-screen pipes
        game.pipes = game.pipes.filter(pipe => pipe.x > -PIPE_WIDTH - 10);

        // Score
        game.pipes.forEach(pipe => {
          if (!pipe.scored && pipe.x + PIPE_WIDTH < BIRD_X) {
            pipe.scored = true;
            game.score++;
          }
        });

        // Collision detection with slightly forgiving hitbox
        const hitMargin = 3;
        const birdTop = bird.y - 12 + hitMargin;
        const birdBottom = bird.y + 12 - hitMargin;
        const birdLeft = BIRD_X - 15 + hitMargin;
        const birdRight = BIRD_X + 15 - hitMargin;

        // Ground collision
        if (birdBottom >= GAME_HEIGHT) {
          bird.y = GAME_HEIGHT - 12 + hitMargin;
          bird.velocity = 0;
          game.state = 'gameover';
          game.flashTimer = 6;
          game.fallDone = true;
          if (game.score > game.bestScore) {
            game.bestScore = game.score;
            try { localStorage.setItem('flappy-best', game.bestScore.toString()); } catch { /* */ }
          }
          return;
        }

        // Ceiling collision
        if (bird.y - 12 <= 0) {
          bird.y = 12;
          bird.velocity = 1;
        }

        // Pipe collision
        for (const pipe of game.pipes) {
          const pipeLeft = pipe.x;
          const pipeRight = pipe.x + PIPE_WIDTH;

          if (birdRight > pipeLeft && birdLeft < pipeRight) {
            if (birdTop < pipe.topHeight || birdBottom > pipe.topHeight + PIPE_GAP) {
              game.state = 'gameover';
              game.flashTimer = 6;
              game.fallDone = false;
              if (game.score > game.bestScore) {
                game.bestScore = game.score;
                try { localStorage.setItem('flappy-best', game.bestScore.toString()); } catch { /* */ }
              }
              break;
            }
          }
        }
      } else if (game.state === 'gameover') {
        if (game.flashTimer > 0) {
          game.flashTimer--;
        }

        if (!game.fallDone) {
          bird.velocity += GRAVITY * 1.5;
          bird.y += bird.velocity;
          bird.rotation = 90;

          if (bird.y + 12 >= GAME_HEIGHT) {
            bird.y = GAME_HEIGHT - 12;
            bird.velocity = 0;
            game.fallDone = true;
          }
        }
      }
    };

    const drawScore = (score: number, y: number) => {
      const assets = assetsRef.current;
      const digits = score.toString().split('');
      // Measure total width
      let totalWidth = 0;
      const digitImgs: HTMLImageElement[] = [];
      digits.forEach(d => {
        const img = assets[d];
        if (img) {
          digitImgs.push(img);
          totalWidth += img.width + 2;
        }
      });
      totalWidth -= 2; // remove last spacing

      let x = (CANVAS_WIDTH - totalWidth) / 2;
      digitImgs.forEach(img => {
        // Draw shadow
        ctx.globalAlpha = 0.3;
        ctx.drawImage(img, x + 2, y + 2);
        ctx.globalAlpha = 1;
        ctx.drawImage(img, x, y);
        x += img.width + 2;
      });
    };

    const roundedRect = (x: number, y: number, w: number, h: number, r: number) => {
      ctx.beginPath();
      ctx.moveTo(x + r, y);
      ctx.lineTo(x + w - r, y);
      ctx.quadraticCurveTo(x + w, y, x + w, y + r);
      ctx.lineTo(x + w, y + h - r);
      ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
      ctx.lineTo(x + r, y + h);
      ctx.quadraticCurveTo(x, y + h, x, y + h - r);
      ctx.lineTo(x, y + r);
      ctx.quadraticCurveTo(x, y, x + r, y);
      ctx.closePath();
    };

    const render = () => {
      const game = gameRef.current;
      const assets = assetsRef.current;

      ctx.clearRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);

      // Background
      const bg = assets['background-day'];
      if (bg) {
        ctx.drawImage(bg, 0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);
      }

      // Pipes
      const pipeImg = assets['pipe-green'];
      if (pipeImg) {
        game.pipes.forEach(pipe => {
          // Bottom pipe (normal orientation)
          ctx.drawImage(pipeImg, pipe.x, pipe.topHeight + PIPE_GAP);

          // Top pipe (flipped vertically)
          ctx.save();
          ctx.translate(pipe.x + PIPE_WIDTH / 2, pipe.topHeight);
          ctx.scale(1, -1);
          ctx.drawImage(pipeImg, -PIPE_WIDTH / 2, 0);
          ctx.restore();
        });
      }

      // Base / ground
      const baseImg = assets['base'];
      if (baseImg) {
        ctx.drawImage(baseImg, -game.baseX, GAME_HEIGHT);
        ctx.drawImage(baseImg, -game.baseX + baseImg.width, GAME_HEIGHT);
      }

      // Bird
      const birdFrame = birdFrames[game.bird.frame];
      const birdImg = assets[birdFrame];
      if (birdImg) {
        ctx.save();
        ctx.translate(BIRD_X, game.bird.y);
        ctx.rotate((game.bird.rotation * Math.PI) / 180);
        ctx.drawImage(birdImg, -birdImg.width / 2, -birdImg.height / 2);
        ctx.restore();
      }

      // Score (during play)
      if (game.state === 'playing') {
        drawScore(game.score, 30);
      }

      // Menu screen
      if (game.state === 'menu') {
        const msgImg = assets['message'];
        if (msgImg) {
          const msgScale = 0.85;
          const sw = msgImg.width * msgScale;
          const sh = msgImg.height * msgScale;
          ctx.drawImage(msgImg, (CANVAS_WIDTH - sw) / 2, 60, sw, sh);
        }
      }

      // Game over screen
      if (game.state === 'gameover') {
        // White flash effect
        if (game.flashTimer > 0) {
          ctx.fillStyle = `rgba(255, 255, 255, ${game.flashTimer / 6})`;
          ctx.fillRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);
        }

        const goImg = assets['gameover'];
        if (goImg) {
          ctx.drawImage(goImg, (CANVAS_WIDTH - goImg.width) / 2, 80);
        }

        // Score panel background
        const panelX = 24;
        const panelY = 135;
        const panelW = CANVAS_WIDTH - 48;
        const panelH = 90;

        // Outer border
        ctx.fillStyle = '#534B28';
        roundedRect(panelX - 2, panelY - 2, panelW + 4, panelH + 4, 10);
        ctx.fill();

        // Inner panel
        ctx.fillStyle = '#DED895';
        roundedRect(panelX, panelY, panelW, panelH, 8);
        ctx.fill();

        // Inner shadow
        ctx.fillStyle = '#C7B967';
        roundedRect(panelX + 4, panelY + 4, panelW - 8, panelH - 8, 6);
        ctx.fill();

        ctx.fillStyle = '#DED895';
        roundedRect(panelX + 6, panelY + 6, panelW - 12, panelH - 12, 5);
        ctx.fill();

        // Score labels
        ctx.fillStyle = '#E87828';
        ctx.font = 'bold 14px Arial, sans-serif';
        ctx.textAlign = 'left';
        ctx.fillText('SCORE', panelX + 20, panelY + 30);

        ctx.fillStyle = '#E87828';
        ctx.fillText('BEST', panelX + 20, panelY + 65);

        // Score values
        ctx.fillStyle = '#FFFFFF';
        ctx.font = 'bold 18px Arial, sans-serif';
        ctx.textAlign = 'right';
        ctx.strokeStyle = '#000';
        ctx.lineWidth = 2;
        ctx.strokeText(game.score.toString(), panelX + panelW - 20, panelY + 30);
        ctx.fillText(game.score.toString(), panelX + panelW - 20, panelY + 30);

        ctx.strokeText(game.bestScore.toString(), panelX + panelW - 20, panelY + 65);
        ctx.fillText(game.bestScore.toString(), panelX + panelW - 20, panelY + 65);
        ctx.textAlign = 'start';
        ctx.lineWidth = 1;

        // Medal
        if (game.score >= 10) {
          const medalColors: Record<string, string[]> = {
            bronze: ['#CD7F32', '#A0522D'],
            silver: ['#C0C0C0', '#808080'],
            gold: ['#FFD700', '#DAA520'],
            platinum: ['#E5E4E2', '#8B8B83'],
          };
          let medalType = 'bronze';
          if (game.score >= 40) medalType = 'platinum';
          else if (game.score >= 30) medalType = 'gold';
          else if (game.score >= 20) medalType = 'silver';

          const mc = medalColors[medalType];
          const mx = panelX + 18;
          const my = panelY + 33;

          // Draw medal circle
          ctx.beginPath();
          ctx.arc(mx + 12, my + 12, 14, 0, Math.PI * 2);
          ctx.fillStyle = mc[1];
          ctx.fill();
          ctx.beginPath();
          ctx.arc(mx + 12, my + 12, 12, 0, Math.PI * 2);
          ctx.fillStyle = mc[0];
          ctx.fill();

          // Star in center
          ctx.fillStyle = mc[1];
          ctx.font = 'bold 14px Arial';
          ctx.textAlign = 'center';
          ctx.fillText('★', mx + 12, my + 17);
          ctx.textAlign = 'start';
        }

        // Restart hint
        if (game.fallDone) {
          const hintAlpha = 0.5 + 0.5 * Math.sin(Date.now() / 300);
          ctx.globalAlpha = hintAlpha;
          ctx.fillStyle = '#FFFFFF';
          ctx.strokeStyle = '#000';
          ctx.lineWidth = 2;
          ctx.font = 'bold 13px Arial, sans-serif';
          ctx.textAlign = 'center';
          ctx.strokeText('TAP OR PRESS SPACE', CANVAS_WIDTH / 2, 268);
          ctx.fillText('TAP OR PRESS SPACE', CANVAS_WIDTH / 2, 268);
          ctx.globalAlpha = 1;
          ctx.textAlign = 'start';
          ctx.lineWidth = 1;
        }
      }
    };

    const gameLoop = () => {
      update();
      render();
      rafRef.current = requestAnimationFrame(gameLoop);
    };

    const startGame = () => {
      gameRef.current = {
        state: 'menu',
        bird: resetBird(),
        pipes: [],
        score: 0,
        bestScore: 0,
        baseX: 0,
        pipeTimer: 0,
        flashTimer: 0,
        fallDone: false,
        menuBobTimer: 0,
      };
      // Load best score from localStorage
      try {
        const saved = localStorage.getItem('flappy-best');
        if (saved) gameRef.current.bestScore = parseInt(saved, 10);
      } catch { /* ignore */ }

      gameLoop();
    };

    loadAll();

    // Input handlers
    const handleKey = (e: KeyboardEvent) => {
      if (e.code === 'Space' || e.code === 'ArrowUp' || e.code === 'KeyW') {
        e.preventDefault();
        handleInput();
      }
    };

    const handleClick = (e: MouseEvent) => {
      e.preventDefault();
      handleInput();
    };

    const handleTouch = (e: TouchEvent) => {
      e.preventDefault();
      handleInput();
    };

    window.addEventListener('keydown', handleKey);
    canvas.addEventListener('click', handleClick);
    canvas.addEventListener('touchstart', handleTouch, { passive: false });

    // Handle resize
    const handleResize = () => {
      const maxH = window.innerHeight * 0.95;
      const maxW = window.innerWidth * 0.95;
      const scaleH = maxH / CANVAS_HEIGHT;
      const scaleW = maxW / CANVAS_WIDTH;
      const s = Math.min(scaleH, scaleW, 3);
      canvas.style.width = `${Math.floor(CANVAS_WIDTH * s)}px`;
      canvas.style.height = `${Math.floor(CANVAS_HEIGHT * s)}px`;
    };

    handleResize();
    window.addEventListener('resize', handleResize);

    return () => {
      cancelAnimationFrame(rafRef.current);
      window.removeEventListener('keydown', handleKey);
      canvas.removeEventListener('click', handleClick);
      canvas.removeEventListener('touchstart', handleTouch);
      window.removeEventListener('resize', handleResize);
    };
  }, [handleInput, resetBird]);

  return (
    <canvas
      ref={canvasRef}
      width={CANVAS_WIDTH}
      height={CANVAS_HEIGHT}
      className="block cursor-pointer"
      style={{
        imageRendering: 'pixelated',
        borderRadius: '4px',
        boxShadow: '0 0 40px rgba(100, 200, 100, 0.3), 0 10px 30px rgba(0,0,0,0.5)',
      }}
    />
  );
}
